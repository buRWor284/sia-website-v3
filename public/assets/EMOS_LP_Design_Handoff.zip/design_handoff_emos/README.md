# Handoff: EMOS Landing Page

## Overview

EMOS (Earned Media Operating System) is a guided implementation program for founders 3 to 12 months from a Series A raise. This landing page is a long-form editorial sales page with 15 sections (§ A through § O) plus a hero, logo marquee, proof bar, and final CTA.

## About the Design Files

The files in this bundle are **design references created in HTML** — high-fidelity prototypes showing intended look and behaviour. The task is to **recreate these designs in your production codebase** (Next.js / React, based on `sia-website-github`) using its established component patterns, routing, and CSS architecture. Do not ship the HTML directly.

The design references an existing design system. The source of truth for all tokens is `colors_and_type.css` / `src/lib/tokens.ts` in the main repo.

---

## Fidelity

**High-fidelity.** The prototypes represent final copy, typography, spacing, colour, and interactions. Recreate pixel-precisely using the SIA design system tokens.

---

## Design System Tokens (source: `colors_and_type.css`)

### Colours

| Token | Value | Usage |
|---|---|---|
| `--color-paper` | `#f1ebde` | Primary background |
| `--color-paper-2` | `#e8e0cc` | Secondary background (alternating sections) |
| `--color-ink` | `#1a1410` | Primary text, borders, dark fills |
| `--color-ink-70` | `rgba(26,20,16,.70)` | Body text |
| `--color-ink-55` | `rgba(26,20,16,.55)` | Muted text, labels |
| `--color-ink-35` | `rgba(26,20,16,.32)` | Subtle borders |
| `--color-ink-15` | `rgba(26,20,16,.15)` | Faint borders, dividers |
| `--color-yellow` | `#f5b81f` | Primary accent: CTAs, pills, highlights |
| `--color-yellow-2` | `#ffc83a` | Yellow hover state |
| `--color-paper-60` | `rgba(241,235,222,.60)` | Body text on dark backgrounds |
| `--color-paper-55` | `rgba(241,235,222,.55)` | Muted text on dark backgrounds |
| `--color-paper-45` | `rgba(241,235,222,.45)` | Subtle text on dark backgrounds |

### Typography

| Token | Value |
|---|---|
| `--font-serif` | `'Newsreader', Georgia, serif` |
| `--font-grot` | `'Archivo', 'Helvetica Neue', sans-serif` |
| `--font-mono` | `'JetBrains Mono', monospace` |

All three fonts are self-hosted from `public/fonts/` (woff2). See `colors_and_type.css` for `@font-face` declarations.

### Type Scale

| Token | Value | Used for |
|---|---|---|
| `--text-xs` | `10px` | SCaps / overlines |
| `--text-sm` | `13px` | Fine print |
| `--text-base` | `16px` | Body |
| `--text-body` | `17.5px` | Long-form body |
| `--text-lg` | `19px` | Lead body |
| `--text-xl` | `22px` | Card heads |
| `--text-2xl` | `28px` | Sub-headlines |
| `--text-3xl` | `clamp(30px, 3.8vw, 52px)` | Section h2 |
| `--text-4xl` | `clamp(36px, 6vw, 72px)` | Large h2 |
| `--text-5xl` | `clamp(40px, 6vw, 76px)` | H1 hero |

### Spacing

| Token | Value |
|---|---|
| Section vertical padding | `80px` mobile · `108px` desktop |
| Section horizontal padding | `20px` mobile · `32px` tablet · `56px` desktop |
| Max content width | `1240px` |

### Borders and Radius

- **Border radius: 0 everywhere.** The SIA design system uses no rounded corners.
- **No box-shadows.** Elevation is expressed through borders only.
- Standard border: `1px solid var(--color-ink)`

---

## Page Structure

The page has a **fixed announcement bar** (yellow, 37px) and **fixed nav** (54px). Body offset: `padding-top: 91px`.

### Section Map

| ID | Label | Background |
|---|---|---|
| `#hero` | Hero | `bg-ink` (dark) |
| Marquee | Logo bar | `paper` with ink borders |
| Proof bar | Stats | `bg-p2` |
| `#built-by` (§ A) | Built By · Syed Irfan Ajmal | `paper` |
| `#how-it-works` (§ B) | Real Problem · 4 Failure Modes | `bg-p2` |
| § C | Investor Lens | `paper` |
| § D | The Numbers | `bg-ink` (dark) |
| § E | Why Now | `paper` |
| `#how-it-works-detail` (§ F) | What You'll Build · 3 Stages | `bg-p2` |
| `#tools` (§ G) | Tools | `paper` |
| § H | 5-Return Framework | `bg-ink` (dark) |
| `#curriculum` (§ I) | Curriculum · Two Tracks | `paper` |
| `#proof` (§ J) | Proof · Testimonials | `bg-p2` |
| § K | Fit Check | `paper` |
| `#calculator` (§ L) | The Math · Authority Cost Calculator | `bg-p2` |
| `#pricing` (§ M) | Investment + Application | `bg-ink` (dark) |
| `#guarantee` (§ N) | Guarantee | `paper` |
| `#faq` (§ O) | FAQ | `bg-p2` |
| Final CTA | — | `bg-ink` (dark) |

---

## Components

### Announcement Bar
- Fixed, `z-index: 110`, top: 0
- Background: `--color-yellow`, border-bottom: `1px solid var(--color-ink)`
- Font: Archivo 700, 11px, `letter-spacing: 0.14em`, uppercase
- Content: `Cohort 1 begins June 8, 2026 · 5 founders · Application required`

### Nav
- Fixed, `z-index: 100`, top: 37px (below announce bar)
- Background: `--color-paper`, border-bottom: `1px solid var(--color-ink)`
- Height: 54px
- Left: `EMOS by Syed Irfan Ajmal` (Archivo 900, 14px)
- Centre: nav links (Archivo 700, 10px, 0.16em spacing, uppercase, `--color-ink-55`, hover `--color-ink`)
- Right: yellow CTA button `Submit Your Application →`
- Nav links hidden at ≤900px

### SectionMast (`.sm`)
Every section starts with a SectionMast: double top rule, pill (§ letter + yellow background), label text, horizontal line, vol number, single closing rule. See `.sm*` classes in `emos-styles.css`.

### Guarantee Block (hero, prominent)
```html
<div class="guarantee-block">
  <span class="guarantee-icon">🛡</span>
  <div class="guarantee-content">
    <span class="guarantee-label">Placements-or-refund guarantee</span>
    <span class="guarantee-body">Every dollar back if we miss what we promised.</span>
  </div>
  <a href="#guarantee" class="guarantee-see-terms">See terms ↓</a>
</div>
```
- Border: `1px solid rgba(245,184,31,.40)` with `border-left: 4px solid var(--color-yellow)`
- Background: `rgba(245,184,31,.07)`
- Label: Archivo 900, 11px, yellow, `letter-spacing: 0.18em`, uppercase
- Body: Newsreader 700, 17px, `--color-paper`

### Interactive Tier-1 Cards (`.t1-grid`)
Expandable cards used in sections B (failure modes), G (tools), and J (testimonials). On click, the card expands to show `.t1-body` content and inverts to dark background. On desktop, an expanded card in a 3-col grid spans 2 columns.

**States:**
- Default: `background: --color-paper`
- Open (`data-open` attribute): `background: --color-ink`, `color: --color-paper`
- Only one card open per grid at a time

**Key sub-elements:**
- `.t1-logo` — icon/avatar area (white bg, ink border)
- `.t1-stat` — large stat/name (Newsreader 700, ~38px, yellow when open)
- `.t1-stat-sub` — small caps label
- `.t1-name` / `.t1-sector` — meta row
- `.t1-body` — hidden until open; contains `.t1-rl` (label) + `.t1-rv` (value) pairs

**JS behaviour:**
```javascript
grid.querySelectorAll('.t1').forEach(card => {
  card.addEventListener('click', e => {
    if (e.target.closest('a') && card.hasAttribute('data-open')) return;
    const isOpen = card.hasAttribute('data-open');
    grid.querySelectorAll('.t1[data-open]').forEach(c => c.removeAttribute('data-open'));
    if (!isOpen) card.setAttribute('data-open', '');
  });
});
```

### Accordion (`.acc-item`)
Used in Curriculum (§ I) and FAQ (§ O).
- Toggle button: `.acc-q` (full width, flex, space-between)
- Icon: `+` rotates to `×` on open via `transform: rotate(45deg)`
- Body: `max-height: 0` → `max-height: 600px` on `.open` class
- Only one item open at a time within a parent container

```javascript
document.querySelectorAll('.acc-q').forEach(btn => {
  btn.addEventListener('click', () => {
    const item = btn.closest('.acc-item');
    const isOpen = item.classList.contains('open');
    item.parentElement.querySelectorAll('.acc-item.open').forEach(el => el.classList.remove('open'));
    if (!isOpen) item.classList.add('open');
  });
});
```

### Marquee
Dual-track infinite scroll (one forward, one reversed). CSS animation `scroll-left` on `.marquee-track`. Pauses on hover. Duration: 30s forward, 26s reverse.

### Lens Table (§ C)
Standard HTML table. Last row has a subtle yellow-tinted background: `oklch(96% .06 80 / .35)`.

### Stage Cards (§ F)
3-column grid, no border-radius, `border: 1px solid var(--color-ink-15)` (right border omitted, last child adds it back). Each card has a large ghost number (Newsreader, 80px, `--color-ink-15`), yellow left-border accent on the outcome paragraph.

### Pricing Cards (§ M)
2-column grid in a dark section. Best Value card has `border: 2px solid var(--color-yellow)` and a yellow badge. Features use `✓` (yellow) for included and `·` for not included.

### Application Steps (§ M)
4 numbered steps. Number badge: 26×26px yellow square, Archivo 900, 11px.

### Guarantee Block (§ N)
- Banner: `border-left: 4px solid var(--color-yellow)`, Newsreader 700
- Two-column commit grid: left (paper bg), right (ink bg)

---

## Authority Cost Calculator (§ L)

React component (`emos-calculator.jsx`) mounted into `<div id="emos-calc-root">`.

### Layout (restructured)
Two equal columns with `gap: 48px`:

**Left column — all inputs:**
1. Mode toggle: "Monthly agency retainer" vs "Link-buying spend / month"
2. Spend slider (label/range changes per mode)
3. Traffic slider (monthly visitors, 200 to 50,000)
4. AOV slider (average order/deal value, $50 to $10,000)
5. Track selector: Foundation ($2,000) vs Accelerate ($3,500)

**Right column — all outputs:**
1. "Where you stand today" snapshot (3-cell grid: CVR, customers, annual rev)
2. 12-month net position: two comparison bars (Renting vs Owning)
3. Result card (dark): 12-month net improvement, ROI %, payback period, monthly gain
4. CTA: Submit Your Application
5. Locked assumptions footnote

### State
`mode`, `spend`, `traffic`, `aov`, `tier` — all persisted to `localStorage` under key `emos.calc.v1`.

### Responsive
Collapses to 1 column at ≤820px.

---

## Interactions and Behaviour

| Interaction | Behaviour |
|---|---|
| Section fade-in | `IntersectionObserver` on every `<section>`: `opacity: 0 → 1`, `translateY(12px) → none`, `transition: 0.5s ease`. First section starts visible. |
| Tier-1 card open/close | `data-open` attribute toggle, grid column span 2 in 3-col grids |
| Accordion open/close | `.open` class on `.acc-item` |
| Marquee hover pause | `animation-play-state: paused` on hover |
| Referral bar | `navigator.clipboard.writeText(window.location.href)` on button click |
| Calculator persistence | `localStorage.setItem('emos.calc.v1', JSON.stringify({...}))` |
| Smooth scroll | `scroll-behavior: smooth` on `html` |

---

## Button Styles

| Class | Background | Text | Usage |
|---|---|---|---|
| `.cta-yellow` | `--color-yellow` | `--color-ink` | Primary CTA (paper + ink sections) |
| `.cta-ink` | `--color-ink` | `--color-yellow` | Secondary CTA (paper sections) |
| `.cta-ghost` | transparent + border | `--color-paper` | Tertiary (dark sections) |

All buttons: Archivo 800, 12px, `letter-spacing: 0.12em`, uppercase. No border-radius.

---

## Copy and Content

All copy is final and should be reproduced exactly. Key guarantees mentioned:
- Foundation: 1 verified placement in 60 days
- Accelerate: 2 verified placements in 90 days
- Full refund if missed

Cohort 1 details: June 8, 2026 · 5 founders · Application required.

---

## Assets

| Asset | Path | Usage |
|---|---|---|
| Headshot | `assets/headshot.jpg` | Bio photo § A |
| Brett Helling | `assets/testimonials/brett-helling.jpeg` | Testimonial § J |
| Azzam Sheikh | `assets/testimonials/azzam-sheikh.jpeg` | Testimonial § J |
| Fonts (woff2) | `fonts/` | Newsreader, Archivo, JetBrains Mono |

Testimonials without photos use initials in a 40×40px ink-coloured square with yellow text (`.avatar-init`).

---

## Files in This Bundle

| File | Purpose |
|---|---|
| `EMOS Landing Page v3.html` | Full page design reference (final version) |
| `emos-styles.css` | All page-specific CSS classes |
| `colors_and_type.css` | Design system tokens, font-faces, utility classes |
| `emos-calculator.jsx` | React calculator component (Babel/UMD, mount via ReactDOM.createRoot) |

The production implementation should replace the Babel/UMD React setup with the app's standard React bundler. The calculator component logic (state, compute functions, formatters) is production-ready; only the mount pattern needs adapting.

---

## Notes for the Developer

1. **No rounded corners anywhere.** `border-radius: 0` is a hard design system rule.
2. **No box-shadows.** Use borders for elevation.
3. The `·` interpunct (`&nbsp;·&nbsp;`) is used as a separator throughout — not a dash.
4. The double-rule SectionMast pattern (`.sm`) should be implemented as a shared component — it appears on every section.
5. The calculator's `calcCompute()` function uses locked assumptions (defined in `A_LOCKED`). These are intentional — do not make them editable.
6. Testimonial quotes should be treated as immutable — do not rephrase.
7. The announcement bar and nav are fixed-position with `z-index: 110` and `100` respectively. Body needs `padding-top: 91px`.
