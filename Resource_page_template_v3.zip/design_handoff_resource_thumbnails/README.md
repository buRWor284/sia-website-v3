# Handoff: Resources Page — Row Thumbnails

## Overview

Add a thumbnail to each resource row on the `/resources` page. The thumbnail sits to the left of the row's title and description, giving users a visual hook before they read the title. The design uses a short italic serif "teaser" line inside each thumbnail to drive clicks — no photography required.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes showing intended look and behaviour, not production code to copy directly. The task is to recreate these designs in the existing Next.js codebase (`sia-website-v3`) using its established patterns, components, and the SIA design system tokens already in use there.

The selected option is **Option B** (the lower section in the mockup). Option A is included for reference only and should not be implemented.

## Fidelity

**High-fidelity.** Exact colours, typography, spacing, and layout are specified below. Recreate pixel-precisely using the codebase's existing design system tokens.

---

## The Thumbnail Component

Each resource row gets a thumbnail inserted **between** the row number and the title/description block.

### Anatomy

```
[row number] [THUMBNAIL] [title + description]     [collection label] [→]
```

### Thumbnail dimensions

| Property | Value |
|---|---|
| Width | 96px |
| Height | 96px |
| Border | 1.5px solid `#1a1410` (var --color-ink) |
| Border radius | 0 (none — brand rule) |
| Margin right | 20px |
| Align self | center |

### Internal layout

The thumbnail is a flex column with `justify-content: space-between` and `padding: 8px 9px`. Three layers from top to bottom:

1. **Category overline** — Archivo, 7px, 700 weight, letter-spacing 0.16em, uppercase. Colour depends on background (see colour variants below).
2. **Hook/teaser line** — Newsreader italic, 13.5px, 600 weight, line-height 1.25. Colour depends on background. This is the clickbait text — a short punchy sentence (≤8 words) that teases the payoff of the resource.
3. **Bottom rule** — full-width, height 2px, `#f5b81f` yellow (or `#1a1410` on yellow bg).

### Colour variants by resource type

Each resource type gets a distinct background. Assign consistently across all rows of the same type:

| Resource type | Background | Category text colour | Hook text colour | Bottom rule |
|---|---|---|---|---|
| VIDEO | `#f1ebde` (paper) | `rgba(26,20,16,.45)` | `#1a1410` | `#f5b81f` |
| PLAYBOOK | `#1a1410` (ink) | `rgba(241,235,222,.40)` | `#f1ebde` | `#f5b81f` |
| INTERACTIVE TOOL | `#f5b81f` (yellow) | `rgba(26,20,16,.60)` | `#1a1410` | `#1a1410` |
| GUIDE | `#e8e0cc` (paper-2) | `rgba(26,20,16,.45)` | `#1a1410` | `#f5b81f` |
| INTERACTIVE KIT | `#f1ebde` (paper) | `rgba(26,20,16,.45)` | `#1a1410` | `#f5b81f` |
| TOOL | `#f5b81f` (yellow) | `rgba(26,20,16,.60)` | `#1a1410` | `#1a1410` |

If a new type is added that has no colour mapping, default to paper background.

---

## Hook/Teaser Copy

Each resource needs a short teaser line written for the thumbnail. The copy must be:
- Italic Newsreader, ≤8 words
- Punchy and specific — implies a payoff or reveals a tension
- No emoji, no exclamation marks, sentence case
- Written as if a seasoned journalist is teasing the lede

### Example lines from the mockup

| Resource | Hook line |
|---|---|
| How PressIQ Works (video) | Watch it score a pitch in real time |
| Personal Branding 101 | Most founders get this completely wrong |
| PressIQ Pitch Score (tool) | Score your pitch in under 60 seconds |
| 100+ Writing Tips | 100 tips. One place. No filler |

**The developer (Claude Code) is responsible for writing all 20 hook lines** — one per resource. Use the examples above as a template. The lines must be sharp, specific, and earn their place: imagine a seasoned journalist teasing the lede of a story. Avoid generic phrases like "learn how to…" or "a guide to…" — those belong in the description, not the thumbnail. Each line should make a reader feel they'd be missing out if they didn't click.

---

## Row Layout Changes

The existing row layout shifts from:

```
[number] [title + description]    [collection] [→]
```

to:

```
[number] [thumbnail 96×96] [title + description]    [collection] [→]
```

- The number column stays at its current width (~40px), left-aligned, vertically centred.
- The thumbnail is inserted immediately after the number, `margin-right: 20px`, `align-self: center`.
- Everything else in the row is unchanged.
- Row `padding` should be adjusted if needed so the thumbnail has breathing room — the mockup uses `padding: 16px 0` per row.

---

## Typography

All values are from the existing SIA design system:

| Token | Family | Size | Weight | Style |
|---|---|---|---|---|
| Category overline | Archivo | 7px | 700 | Normal, uppercase, ls 0.16em |
| Hook/teaser | Newsreader | 13.5px | 600 | Italic |
| Row title | Newsreader | 15px | 600 | Normal |
| Row description | Archivo | 11px | 400 | Normal |
| Collection label | Archivo | 9px | 400 | Normal, uppercase, ls 0.1em |

---

## Design Tokens Used

All already present in the SIA design system:

| Token | Value |
|---|---|
| `--color-paper` | `#f1ebde` |
| `--color-paper-2` | `#e8e0cc` |
| `--color-ink` | `#1a1410` |
| `--color-yellow` | `#f5b81f` |
| `--color-ink-55` | `rgba(26,20,16,.55)` |
| `--color-ink-35` | `rgba(26,20,16,.32)` |
| `--color-ink-15` | `rgba(26,20,16,.15)` |

---

## Interactions

- **Hover state on the row**: the existing row hover behaviour is unchanged. The thumbnail does not have its own isolated hover state — it moves with the row.
- **No animation** on the thumbnail itself — consistent with the brand's zero-animation principle.
- Transition on row hover (if currently present): `0.12s ease` colour/opacity change only.

---

## Assets

No image assets are required. The thumbnails are entirely typographic — category label, hook text, and a coloured rule. No icons, no photographs.

---

## Files in This Package

| File | Description |
|---|---|
| `README.md` | This document |
| `Resource Thumbnails.dc.html` | Full HTML design reference showing both Option A and the selected Option B with four example rows |
| `screenshot-option-b-selected.png` | Screenshot of the selected Option B thumbnail rows |
| `screenshot-option-a.png` | Screenshot of Option A (reference only, not to be implemented) |

---

## Out of Scope

- Writing the 20 hook lines — needs content owner input.
- Responsive behaviour below tablet — the mockup is desktop-width. Discuss with SIA whether thumbnails collapse or hide on mobile.
- Any changes to the filter bar, section headers, or other parts of the resources page.
