# Refund Policy

**Last updated: {{DATE}}**

We want you to be satisfied with {{PRODUCT_NAME}}. This policy explains how refunds, returns, and cancellations work.

## Refund window

If you are not satisfied with your purchase, you may request a refund within **{{REFUND_WINDOW}} days** of the purchase date. (A 14-day window is common for one-time digital products; 30 days is common for annual subscriptions.)

## How to request a refund

Email **{{SUPPORT_EMAIL}}** from the email address you used at checkout and include your order number. We review refund requests within **{{REVIEW_DAYS}} business days** and will confirm by email.

## What's eligible

Purchases of {{PRODUCT_NAME}} are eligible for a refund within the window above. Any clearly stated non-refundable items, or items that have been substantially consumed, will be disclosed at checkout before you pay.

## Subscriptions (if applicable)

You can cancel a subscription at any time via {{ACCOUNT_AREA_OR_CONTACT}}. Cancelling stops all future charges. {{State here whether the current billing period is refundable or runs to its end.}}

## How refunds are issued

Approved refunds are returned to your original payment method through our payment processor. Depending on your bank or card issuer, it can take several business days for the refund to appear.

## Payment processor

Payments are processed by **{{PROCESSOR_NAME, e.g., 2Checkout / Verifone}}**, who may help facilitate refund requests and reserves the right to issue a refund where appropriate.

## Contact

Questions about a refund? Email **{{SUPPORT_EMAIL}}**.

---

*This template is provided for convenience and is not legal advice. Please review and adapt it (ideally with a qualified professional) before publishing.*
