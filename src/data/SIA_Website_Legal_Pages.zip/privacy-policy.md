# Privacy Policy

**Last updated: {{DATE}}**

{{LEGAL_ENTITY_NAME}} ("we", "us", "our") operates {{WEBSITE_URL}} and provides {{PRODUCT_NAME}} (the "Service"). This policy explains what personal information we collect, how we use it, who we share it with, and your rights.

## Information we collect

- **Information you provide:** your name, email address, billing details, and anything you submit when you contact us or place an order.
- **Payment information:** payments are handled by our payment processor(s) (for example, 2Checkout / Verifone). We do **not** store full card numbers on our servers — card data is processed by the PCI-DSS-compliant payment provider.
- **Usage data:** basic technical information such as IP address, browser type, and pages visited, collected through cookies and similar technologies.

## How we use your information

We use your information only to: process and deliver your order; provide customer support; send you communications related to your order or account; comply with our legal, tax, and accounting obligations; and detect and prevent fraud.

## How we share your information

We do **not** sell or rent your personal information. We share it only with:

- our payment processor(s), to complete and support your purchase;
- service providers who help us operate the Service (for example, hosting and email providers); and
- authorities or third parties where we are required to do so by law.

## Cookies

We use cookies to operate the site and understand how it is used. You can control or disable cookies through your browser settings.

## Data retention

We keep your personal data only as long as necessary for the purposes described above and to meet our legal and tax obligations.

## Your rights

Depending on where you live, you may have the right to access, correct, delete, or restrict the processing of your personal data, or to object to it. To exercise any of these rights, email us at **{{SUPPORT_EMAIL}}**.

## International transfers

Because we serve customers globally, your information may be processed in countries other than your own. Where this happens, we take steps to protect it consistent with this policy.

## Security

We use reasonable technical and organizational measures to protect your personal information.

## Contact

{{LEGAL_ENTITY_NAME}}
{{BUSINESS_ADDRESS}}
Email: **{{SUPPORT_EMAIL}}**

---

*This template is provided for convenience and is not legal advice. Please review and adapt it (ideally with a qualified professional) before publishing.*
