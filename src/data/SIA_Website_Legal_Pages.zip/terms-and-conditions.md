# Terms and Conditions

**Last updated: {{DATE}}**

These Terms govern your access to and use of {{WEBSITE_URL}} and {{PRODUCT_NAME}} (the "Service"), provided by {{LEGAL_ENTITY_NAME}} ("we", "us", "our"). By purchasing or using the Service, you agree to these Terms.

## 1. The Service

{{Briefly describe EMOS: what the buyer receives, how it is delivered, and how they access it.}}

## 2. Eligibility

You must be legally able to enter into a binding contract to purchase or use the Service.

## 3. Orders and payment

Prices are displayed at checkout in {{CURRENCY}}. Payments are processed by **{{PROCESSOR_NAME}}**, acting as our payment processor / merchant of record. By placing an order, you authorize the applicable charge. Your order is confirmed once payment is approved and access to the Service is provided.

## 4. Refunds

Refunds are governed by our Refund Policy, available at {{REFUND_POLICY_URL}}.

## 5. License and acceptable use

We grant you a limited, non-exclusive, non-transferable license to use {{PRODUCT_NAME}} for your own {{personal / business}} use. You may not resell, redistribute, sublicense, or reverse-engineer the Service except where permitted by law.

## 6. Intellectual property

All content and materials within the Service are owned by {{LEGAL_ENTITY_NAME}} or its licensors and are protected by applicable intellectual-property laws.

## 7. Disclaimers

The Service is provided "as is" and "as available," without warranties of any kind, to the fullest extent permitted by law.

## 8. Limitation of liability

To the maximum extent permitted by law, our total liability for any claim arising out of or relating to the Service is limited to the amount you paid for it.

## 9. Changes

We may modify the Service and these Terms from time to time. Material changes will be posted on this page with an updated "Last updated" date.

## 10. Governing law

These Terms are governed by the laws of {{GOVERNING_LAW_JURISDICTION}}, without regard to its conflict-of-laws rules.

## 11. Contact

{{LEGAL_ENTITY_NAME}} — **{{SUPPORT_EMAIL}}** — {{BUSINESS_ADDRESS}}

---

*This template is provided for convenience and is not legal advice. Please review and adapt it (ideally with a qualified professional) before publishing.*
