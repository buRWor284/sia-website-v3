# Handoff: Resources Page — Expandable Card Redesign

## Overview

This handoff covers a redesign of the **Resources page card grid** (`/resources`). The core change: each resource card now uses the same **expandable t1 card pattern** from the Clients page — clicking `+` flips the card to a dark ink background, expands it to span 2 columns, and reveals the full blurb, topic tags, and CTA. All other existing functionality (filter bar, hero, "Being Updated" tray) is preserved and refined.

The existing route is `/src/app/resources/page.tsx` with its interactive shell at `/src/components/resources/ResourcesClientShell.tsx`. **Only `ResourcesClientShell.tsx` needs to change.**

---

## About the Design File

`Resources Page.html` is a **high-fidelity design reference** — a self-contained HTML prototype showing the intended look and behaviour. It is not production code. The task is to **re-implement the card expand/collapse pattern shown in the prototype inside the existing Next.js / React codebase**, using the existing token system (`@/lib/tokens`), primitives (`@/components/bureau/primitives`), and React state conventions already in use in `ResourcesClientShell.tsx`.

---

## Fidelity

**High-fidelity.** Recreate pixel-accurately. All colours, spacing, typography, border widths, transitions, and interaction states are specified below and visible in the reference HTML.

---

## What's Changing vs. Current Code

| Area | Current | New |
|---|---|---|
| Card closed state | Static card with left-accent border, hover bg change | Same visual base + `+` button top-right |
| Card open state | Does not exist | Dark ink bg, 2-column span, full blurb + topics + CTA |
| Grid gap | CSS Grid `border` per cell | `gap: 1px; background: INK` (creates 1px ink lines) |
| Newspaper snippet position | Top of card | Same — now also the "logo zone" analog in expand pattern |
| One-card-open rule | N/A | Only one card open at a time; opening another closes previous |

Everything else — filter bar, hero, `ComingBackSection`, podcast teaser, `Subscriptions`, `Colophon` — stays exactly as-is.

---

## Screens / Views

### 1. Filter Bar (unchanged)
Sticky, `background: INK`, `border-bottom: 2px solid YEL`.

**Row 1 — Type tabs**
- Container: `display:flex; align-items:stretch; padding: 0 20px; overflow-x:auto; border-bottom: 1px solid rgba(241,235,222,.10)`
- Each tab: `padding: 11px 14px; font-family: GROT; font-size: 10.5px; font-weight: 600 (inactive) / 800 (active); letter-spacing: .18em; text-transform:uppercase; color: rgba(241,235,222,.48) (inactive) / YEL (active); border-bottom: 2px solid transparent (inactive) / YEL (active); margin-bottom: -2px`
- Count badge: `font-size: 8.5px; font-weight: 700; color: rgba(241,235,222,.22) / YEL`

**Row 2 — Topic pills**
- Container: `display:flex; align-items:center; padding: 7px 20px; gap: 7px; overflow-x:auto`
- Each pill: `padding: 5px 12px 6px; border: 1px solid rgba(241,235,222,.18); font-family: GROT; font-size: 9.5px; font-weight: 600 (inactive) / 800 (active); letter-spacing: .14em; background: transparent / YEL; color: rgba(241,235,222,.5) / INK`
- Transition: `all 0.12s`

---

### 2. Hero Section (unchanged)

3-column grid: `grid-template-columns: 120px 1fr 220px; gap: 40px; padding: 80px 56px 64px`

Left: large number `84px` serif, `letter-spacing: -.04em`, with 9px GROT label below.  
Centre: watermark, SCaps label, h1 `clamp(30px, 3.8vw, 52px)`, italic paragraph.  
Right: topic index list — 17px serif titles + 9px GROT subcategories.

---

### 3. Resource Card — **THE KEY CHANGE**

The card is a `<div>` (not `<a>`) at the top level to support the expand pattern. Internal CTA links remain `<a>`.

#### Closed state

```
┌──────────────────────────────────────────┐
│  [Newspaper snippet ──────────────────]  [+] │
│                                              │
│ [accent border-left] [§01] [Badge]  [Beta]  │
│ ─────────────────────────────────────────── │
│  Title (Newsreader 700 21px)                │
│  Sub-headline (Newsreader italic 14.5px)    │
│ ─────────────────────────────────────────── │
│  Year              CTA ↗                    │
└──────────────────────────────────────────────┘
```

**Container:** `display:flex; flex-direction:column; background: PAPER; cursor:pointer; transition: background .22s, color .22s`

**`+` button (top right):**
- `width: 22px; height: 22px; border: 1px solid INK; background: none`
- `font-family: GROT; font-weight: 800; font-size: 14px; color: INK`
- When card is open: `border-color: PAPER; color: PAPER`

**Newspaper snippet:**
- Container: `flex:1; background: PAPER2; border: 1px solid INK; padding: 8px 10px; min-height: 72px; overflow:hidden`
- Hidden when card is open (`display:none`)
- Internal:
  - "Bureau Gazette" label: `font-family: GROT; font-weight: 900; font-size: 6px; letter-spacing: .28em; text-transform: uppercase; color: INK55`
  - Double rule: `border-top: 2px solid INK` then `border-top: .75px solid INK; margin-bottom: 6px`
  - Headline: `font-family: SERIF; font-weight: 700; font-size: 12px; line-height: 1.15; text-transform: uppercase; letter-spacing: -.005em; color: INK; margin-bottom: 5px`
  - Deck: `font-family: SERIF; font-size: 7px; color: INK55; line-height: 1.5`

**Type row** (below snippet):
- `border-top: 1px solid INK; border-bottom: 1px solid INK; padding: 10px 20px`
- `border-left: 3px solid <TYPE_ACCENT>` — see accent colours table below
- When open: border colours → `rgba(241,235,222,.25)`

**Index badge:** `background: YEL; color: INK; font-family: GROT; font-weight: 800; font-size: 8.5px; letter-spacing: .16em; padding: 3px 7px 4px`

**Status badges:**
- Beta: `background: #D4A017; color: INK; font-size: 7.5px; padding: 2px 7px`
- Coming Soon: `background: INK; color: PAPER` (open state: `background: rgba(241,235,222,.15)`)
- Under Review: `background: rgba(26,20,16,.1); border: 1px solid INK15; color: INK55`

**Title:** `font-family: SERIF; font-weight: 700; font-size: 21px; letter-spacing: -.015em; line-height: 1.1; color: INK` → open: `color: PAPER`

**Sub:** `font-family: SERIF; font-style: italic; font-size: 14.5px; color: INK55; margin-top: 5px` → open: `color: rgba(241,235,222,.55)`

**Footer row** (closed only, hidden when open):
- `border-top: 1px solid INK15; padding: 12px 20px; display:flex; justify-content:space-between`
- Year: `font-family: GROT; font-size: 9px; letter-spacing: .14em; text-transform: uppercase; color: INK55`
- CTA: `font-family: GROT; font-size: 10px; letter-spacing: .16em; text-transform: uppercase; color: INK`

---

#### Open / Expanded state

Triggered by clicking `+`. Card receives `data-open` or equivalent boolean state flag.

**Container changes:**
- `background: INK; color: PAPER`
- `grid-column: span 2` — **critical**: card takes up 2 of the 3 grid columns

**Body (hidden when closed, flex column when open):**
- Padding: `0 20px 20px`

**Blurb:** `font-family: SERIF; font-size: 15.5px; color: rgba(241,235,222,.78); line-height: 1.65; margin-bottom: 18px`

**Topic tags row:** `display:flex; gap: 6px; flex-wrap: wrap; margin-bottom: 20px`
- Each tag: `padding: 4px 9px 5px; border: 1px solid rgba(241,235,222,.2); font-family: GROT; font-weight: 700; font-size: 8.5px; letter-spacing: .14em; text-transform: uppercase; color: rgba(241,235,222,.45)`

**CTA row:** `border-top: 1px solid rgba(241,235,222,.15); padding-top: 16px; display:flex; align-items:center; gap:16px; margin-top:auto`

**CTA link (ghost button):**
- `padding: 10px 18px; border: 1px solid PAPER`
- `font-family: GROT; font-weight: 700; font-size: 10px; letter-spacing: .18em; text-transform: uppercase; color: PAPER`
- Hover: `background: PAPER; color: INK`
- Transition: `background .15s, color .15s`
- For "Coming Soon" items: render a muted label instead — `color: rgba(241,235,222,.35)`, no link, text "Available Soon"

**Year label (right of CTA):** `font-family: GROT; font-size: 9px; letter-spacing: .14em; color: rgba(241,235,222,.3)`

---

### 4. Type Accent Colours

```ts
const TYPE_ACCENT: Record<ContentType, string> = {
  kit:           '#f5b81f',   // yellow
  tool:          '#C17817',   // amber
  calculator:    '#5B8A72',   // teal
  quiz:          '#8B6B99',   // purple
  playbook:      INK,         // #1a1410
  article:       INK55,       // rgba(26,20,16,.55)
  'visual-essay': '#A0522D',  // sienna
};
```

Used as `border-left: 3px solid <accent>` on the type row.

---

### 5. Grid

```tsx
// Outer grid
<div style={{
  display: 'grid',
  gridTemplateColumns: 'repeat(3, 1fr)',
  gap: '1px',
  background: INK,              // ← creates 1px ink dividers
  border: `1px solid ${INK}`,
}}>
  {items.map((item, i) => (
    <ResourceCard
      key={item.id}
      item={item}
      index={i}
      isOpen={openId === item.id}
      onToggle={() => setOpenId(openId === item.id ? null : item.id)}
    />
  ))}
</div>
```

Each card's open state needs `grid-column: openId === item.id ? 'span 2' : 'span 1'` applied as an inline style or CSS class.

---

### 6. "Being Updated" Tray (unchanged, `ComingBackSection`)

4-column grid, `gap: 1px; background: INK15; border: 1px solid INK15`. Cards `opacity: 0.55`, left accent border by type.

---

## Interactions & Behaviour

### Expand / Collapse

```tsx
const [openId, setOpenId] = useState<string | null>(null);

// In card:
onClick={() => setOpenId(prev => prev === item.id ? null : item.id)}

// On + button: e.stopPropagation() so clicking the button doesn't bubble to card
```

- **Only one card open at a time.** Opening card B while A is open closes A automatically (handled by single `openId` string).
- `+` text becomes `×` when the card is open.
- Smooth re-layout — no animation required, just CSS `transition: background .22s, color .22s`.
- No scroll-into-view needed (the layout shift is visible in place).

### Filtering

No changes to existing filter logic in `ResourcesClientShell.tsx`. Only the card rendering changes.

### Hover states

- Card (closed): `background: PAPER2` on hover — keep existing `onMouseEnter`/`onMouseLeave` pattern, but skip hover effect when card is open.
- CTA link: `background: PAPER; color: INK` on hover.
- `+` button: no additional hover (the border/color change on open is sufficient).

### Responsive

| Breakpoint | Grid columns | Open card span |
|---|---|---|
| ≥ 860px | 3 columns | span 2 |
| 560–860px | 2 columns | span 1 (full width on mobile — don't span) |
| < 560px | 1 column | span 1 |

---

## State Management

Add a single new state variable to `ResourcesClientShell.tsx`:

```tsx
const [openId, setOpenId] = useState<string | null>(null);
```

Pass it down to `ContentGrid` and then to each `ResourceCard`. When the active type or topic filter changes, reset `openId` to `null` (call `setOpenId(null)` inside `setActiveType` and `toggleTopic`).

---

## Design Tokens Used

All tokens are already in `@/lib/tokens.ts` — no new tokens needed.

| Token | Value | Usage |
|---|---|---|
| `PAPER` | `#f1ebde` | Card closed background |
| `PAPER2` | `#e8e0cc` | Card hover bg, newspaper snippet bg |
| `INK` | `#1a1410` | Card open background, grid gap, borders |
| `INK70` | `rgba(26,20,16,.70)` | Body text |
| `INK55` | `rgba(26,20,16,.55)` | Muted labels, badge text |
| `INK15` | `rgba(26,20,16,.15)` | Footer border, updating grid bg |
| `YEL` | `#f5b81f` | Index badge, beta badge, active filter |
| `SERIF` | CSS var | Titles, blurb, sub-headline |
| `GROT` | CSS var | All caps labels, badges, tabs |

**New values (not in tokens, use inline):**

| Purpose | Value |
|---|---|
| Open card blurb text | `rgba(241,235,222,.78)` |
| Open card topic tags | `rgba(241,235,222,.45)` |
| Open card type row border | `rgba(241,235,222,.25)` |
| Open card CTA year | `rgba(241,235,222,.3)` |
| Tool accent | `#C17817` |
| Calculator accent | `#5B8A72` |
| Quiz accent | `#8B6B99` |
| Visual Essay accent | `#A0522D` |

---

## Files Changed

| File | Change |
|---|---|
| `src/components/resources/ResourcesClientShell.tsx` | Add `openId` state; update `InteractiveCard`, `PlaybookCard`, `ArticleCard`, `VisualEssayCard` to accept `isOpen`/`onToggle` props; update `ContentGrid` to pass `openId`; apply `grid-column: span 2` on open card; update grid to `gap: 1px; background: INK` |
| Nothing else | `page.tsx`, `TocBar.tsx`, `Subscriptions`, `Colophon` — no changes |

---

## Design Reference Files

- `Resources Page.html` — Full hi-fi prototype. Open in a browser to interact with all card states, filters, and the expand/collapse behaviour.
- `emos-diagrams.html` — Companion diagrams (not part of this implementation).
