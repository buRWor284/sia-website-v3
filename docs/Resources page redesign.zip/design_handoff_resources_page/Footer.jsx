// SIA Colophon (Footer)

function Colophon() {
  const COLS = [
    { head:'The Work', items:[
      {label:'Fractional CMO',href:'#fractional-cmo'},{label:'Speaking',href:'#speaking'},
      {label:'EMOS',href:'#emos'},{label:'DMR.agency',href:'https://dmr.agency',ext:true},
      {label:'Clients',href:'#'}]},
    { head:'Navigate', items:[
      {label:'Home',href:'#home'},{label:'About',href:'#about'},
      {label:'Podcast',href:'#'},{label:'Resources',href:'#resources'},
      {label:'Newsletter',href:'#'}]},
    { head:'Elsewhere', items:[
      {label:'Twitter / X',href:'https://x.com/syedirfanajmal',ext:true},
      {label:'LinkedIn',href:'https://www.linkedin.com/in/syedirfanajmal/',ext:true},
      {label:'YouTube',href:'https://youtube.com/@syedirfanajmal/',ext:true},
      {label:'Apple Podcasts',href:'https://podcasts.apple.com/us/podcast/syed-irfan-ajmal/id1347540466',ext:true}]},
  ];

  return React.createElement('footer', {
    style: { background: PAPER, paddingTop:60, paddingBottom:36,
      paddingLeft:56, paddingRight:56, fontFamily:SERIF }
  },
    React.createElement(DoubleRule, { style: { marginBottom:36 } }),
    // Grid
    React.createElement('div', { style: { display:'grid', gridTemplateColumns:'1.6fr 1fr 1fr 1fr', gap:40, paddingBottom:36 } },
      // Brand
      React.createElement('div', null,
        React.createElement('div', { style: { fontFamily:SERIF, fontWeight:700, fontSize:36,
          color:INK, lineHeight:1, letterSpacing:'-0.02em' } }, 'Syed Irfan Ajmal'),
        React.createElement('p', { style: { marginTop:16, fontFamily:SERIF, fontSize:15.5,
          color:INK70, lineHeight:1.55, maxWidth:340, fontStyle:'italic' } },
          'Serial entrepreneur. Fractional CMO. CEO of DMR.agency. Founder @ EMOS. Bylines & citations: Forbes, HBR, SEMrush & more.')
      ),
      // Link cols
      ...COLS.map(col => React.createElement('div', { key: col.head },
        React.createElement(Pill, { size:11, ls:'0.22em' }, col.head),
        React.createElement('ul', { style: { listStyle:'none', margin:'14px 0 0', padding:0,
          display:'flex', flexDirection:'column', gap:8 } },
          col.items.map(item => React.createElement('li', { key: item.label },
            React.createElement('a', {
              href: item.href,
              target: item.ext ? '_blank' : undefined,
              rel: item.ext ? 'noopener noreferrer' : undefined,
              style: { fontFamily:SERIF, fontSize:16, color:INK, textDecoration:'none', fontWeight:500 }
            }, item.label, item.ext && React.createElement('span', {
              style: { fontSize:11, marginLeft:3, opacity:.5 } }, '↗'))
          ))
        )
      ))
    ),
    React.createElement(DoubleRule),
    React.createElement('div', { style: { display:'flex', justifyContent:'space-between',
      alignItems:'center', paddingTop:18, flexWrap:'wrap', gap:12 } },
      React.createElement(SCaps, { size:10.5, ls:'0.16em', color:INK70 },
        '© MMXXVI · Syed Irfan Ajmal · SIA Enterprises Inc · Wyoming C-Corp'),
      React.createElement('div', { style: { display:'flex', gap:20, alignItems:'center' } },
        ['Privacy Policy','Terms','Refund Policy'].map(l =>
          React.createElement('a', { key:l, href:'#', style: { fontFamily:GROT, fontSize:10.5,
            color:INK70, textDecoration:'none', letterSpacing:'0.16em', textTransform:'uppercase', fontWeight:700 } }, l)
        )
      ),
      React.createElement('div', { style: { display:'flex', alignItems:'center', gap:6 } },
        React.createElement('span', { style: { display:'inline-block', width:8, height:8,
          borderRadius:999, background:YEL, border:`1px solid ${INK}`, verticalAlign:'middle' } }),
        React.createElement(SCaps, { size:10.5, ls:'0.16em', color:INK70 }, 'Open for projects, Q3 2026')
      )
    )
  );
}

Object.assign(window, { Colophon });
