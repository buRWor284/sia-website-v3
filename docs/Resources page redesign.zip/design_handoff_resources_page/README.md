# Handoff: Resources Page (v1 — Ledger Layout)

## Overview
A full-page redesign of the `/resources` route on syedirfanajmal.com. The page serves as a working library of free tools, calculators, guides, and reports on earned media, SEO-PR, and GEO. It also surfaces the podcast, press bylines, and newsletter sign-up.

## About the Design Files
The files in this bundle (`Resources Page v1.html`, `Header.jsx`, `Footer.jsx`, `Primitives.jsx`) are **HTML design references** — high-fidelity prototypes showing intended look and behaviour. They are not production code. The task is to **recreate these designs inside the existing Next.js codebase** (`github.com/buRWor284/sia-website-v3`) using its established patterns, components, and conventions.

## Fidelity
**High-fidelity.** Colors, typography, spacing, interactions, and copy are final. Recreate pixel-accurately using the codebase's existing design system tokens and components wherever possible.

---

## Screens / Views

### 1. Site Header
Reuse the existing `SiteHeader` component. Set the active page to `"Resources"`.

---

### 2. Hero — Newspaper 3-Column Grid

**Layout:** Full-width section, `padding: 0 56px`, `border-bottom: 1px solid #1a1410`.

**Top breadcrumb strip:** flex row, `padding: 8px 0`, `border-bottom: 1px solid rgba(26,20,16,.15)`. Three uppercase Archivo labels (`9px`, `700`, `letter-spacing: 0.22em`, color `rgba(26,20,16,.55)`) separated by mid-dots.
- Labels: `A Working Library · Earned Media · Bespoke Media`

**Grid:** `grid-template-columns: 110px 1fr 210px`

**Left column** (`padding: 36px 28px 36px 0`, `border-right: 1px solid #1a1410`):
- Stat number: Newsreader `700`, `72px`, `line-height: 0.9`, `letter-spacing: -0.04em`. `border-bottom: 2px solid #f5b81f`, `padding-bottom: 4px`. Value: `20`
- Label below: Archivo `700`, `9px`, `letter-spacing: 0.22em`, uppercase, `rgba(26,20,16,.55)`. Text: `Resources`
- Lower sub-labels (separated by `border-top: 1px solid rgba(26,20,16,.15)`, `margin-top: 32px`): `Platforms` and `Infographics` — Archivo `700`, `8.5px`, `rgba(26,20,16,.35)`

**Center column** (`padding: 48px 56px`, `border-right: 1px solid #1a1410`, `overflow: hidden`):
- Ghost watermark: `RESOURCES` in Newsreader `700`, `136px`, `opacity: 0.03`, absolutely centered
- `h1`: Newsreader `700`, `clamp(32px, 4vw, 52px)`, `line-height: 1.0`, `letter-spacing: -0.025em`, color `#1a1410`. Copy: `The frameworks` / `*behind the bylines.*` (second line italic)
- Body copy: Newsreader `400`, `17px`, `line-height: 1.65`, `rgba(26,20,16,.7)`, `max-width: 460px`. Copy: `Interactive tools, playbooks, and original research on media, digital PR, and SEO — packaged to use, not just read.`
- CTA row: flex, `gap: 12px`
  - Yellow button: `padding: 11px 20px`, `background: #f5b81f`, Archivo `800`, `10px`, `letter-spacing: 0.14em`, uppercase. Text: `Browse All →`
  - Ghost link: Archivo `700`, `10px`, `rgba(26,20,16,.55)`. Text: `Syed Irfan Ajmal ↗`

**Right column** (`padding: 32px 28px`): Three dispatch items separated by `border-bottom: 1px solid rgba(26,20,16,.15)`:
1. Label `GEO` + body copy about Generative Engine Optimisation
2. Label `SEO-PR` + body copy
3. Label `Press` + italic serif link `Where the writing has gone →`

---

### 3. Resource Ledger (§ 01)

**Layout:** `padding: 0 56px 90px`. Section starts 40px below hero.

**Double-rule section mast:** Standard SIA pattern — `1px` top rule + `3px` rule 3px below + label row + closing `1px` rule.
- Yellow pill: `§ 01`, Archivo `800`, `10.5px`, `letter-spacing: 0.18em`, `background: #f5b81f`
- Label: `All Resources`, Archivo `700`, `11px`, `letter-spacing: 0.22em`, `rgba(26,20,16,.55)`
- Right meta: `Vol. XV · № 01`

**Filter bar** (`padding: 18px 0 16px`, `border-bottom: 1px solid rgba(26,20,16,.15)`):
Filter buttons — Archivo `700`, `9.5px`, `letter-spacing: 0.16em`, uppercase, `padding: 7px 16px`.
- Active state: `background: #1a1410`, `color: #fafafa`, `border: 1px solid #1a1410`
- Inactive state: `background: transparent`, `color: rgba(26,20,16,.55)`, `border: 1px solid rgba(26,20,16,.22)`
- Hover: border and text flip to full ink
- Buttons: `All · 14`, `Tools · 6`, `Calculators · 1`, `Guides · 5`, `Reports · 2`

**Category header row** (`padding: 28px 0 12px`, `border-bottom: 1px solid #1a1410`):
- Category label: Archivo `700`, `10.5px`, `letter-spacing: 0.22em`, uppercase, `#1a1410`
- Right count: Archivo `700`, `9.5px`, `rgba(26,20,16,.35)`
- Divider line between: `1px solid rgba(26,20,16,.15)`

**Resource rows** — each row is a CSS grid: `grid-template-columns: 40px 130px 1fr 186px 36px`, `gap: 20px`, `padding: 22px 0`, `border-bottom: 1px solid rgba(26,20,16,.15)`.
- **Col 1 — Index:** Archivo `700`, `10px`, `letter-spacing: 0.2em`, `rgba(26,20,16,.35)`. e.g. `01`
- **Col 2 — Pill:** `background: #f5b81f`, Archivo `800`, `9.5px`, `letter-spacing: 0.15em`, uppercase, `padding: 5px 10px 6px`. Values: `Tool`, `Calc`, `Guide`, `Report`
- **Col 3 — Title + desc:**
  - Title: Newsreader `700`, `21px`, `line-height: 1.15`, `letter-spacing: -0.01em`, `#1a1410`
  - Desc: Newsreader italic `400`, `15px`, `line-height: 1.55`, `rgba(26,20,16,.7)`, `margin-top: 6px`
- **Col 4 — Source:** Archivo `700`, `9.5px`, `letter-spacing: 0.18em`, uppercase, `rgba(26,20,16,.55)`, `text-align: right`
- **Col 5 — Arrow CTA:** `→` in Newsreader `22px`, `#1a1410`. On row hover: arrow turns `#f5b81f`
- **Row hover:** `background: #e8e0cc` (paper-2)

**Category order:** Interactive Tools → Calculators → Guides & Ebooks → Reports & Deep Dives

**Resource data:**

| # | Cat | Title | Source |
|---|-----|-------|--------|
| 01 | Tool | How PresIQ Works | The Pitch Desk |
| 02 | Tool | PresIQ – Journalist Pitch Score | Score & Pitch |
| 03 | Tool | SignalIQ – Proactive PR Radar | The Footprint Desk |
| 04 | Tool | JournoCollabIQ – Journalist Beat Matcher | The Media Lift |
| 05 | Tool | The Journey Outreach Checklist | Focus Perfect |
| 06 | Tool | Partner CollabIQ – Partnership Intelligence Tool | The Partnership Desk |
| 07 | Calc | SIA Authority ROI Calculator | Beyond vs. Owning |
| 08 | Guide | Personal Branding 101 | The Authority Playbook |
| 09 | Guide | Storytelling 101 | The Narrative Framework |
| 10 | Guide | Neuromarketing 101 | The Persuasion Code |
| 11 | Guide | 100+ Writing Tips to Become a Great Writer | The Writer's Blueprint |
| 12 | Guide | Top 11 Scientific Benefits of Writing | Writing in Weekend |
| 13 | Report | How to Win on Bing and the AI Answer Engines It Feeds | The SEO Report |
| 14 | Report | Blog SEO: The 2015 Original | The Archive |

---

### 4. Podcast (§ 02) — Dark Section

**Background:** `#1a1410` (ink). `padding: 70px 56px`.

**Section mast:** Same double-rule pattern, rules use `rgba(241,235,222,.5)`. Label: `Podcast · 39 Episodes`.

**Layout:** `grid-template-columns: 1fr 1fr`, `gap: 80px`.

**Left:**
- `h2`: Newsreader `700`, `clamp(36px, 5vw, 64px)`, `line-height: 0.96`, `letter-spacing: -0.03em`, `#f1ebde`. Copy: `The show` / `*on the air.*` (second line italic yellow `#f5b81f`)
- Body: Newsreader `400`, `16px`, `line-height: 1.65`, `rgba(241,235,222,.7)`, `max-width: 380px`

**Right:**
- Overline: Archivo `700`, `9px`, `rgba(241,235,222,.4)`. Text: `Browse the archive`
- Body text (same style as left)
- Two buttons: Yellow CTA (`Go to the podcast →`) + ghost outline button (`Apple Podcasts ↗`) with `border: 1px solid rgba(241,235,222,.35)`, `color: rgba(241,235,222,.7)`

---

### 5. Publications (§ 03) — Paper Section

`padding: 70px 56px`. **Layout:** `grid-template-columns: 1fr 1.3fr`, `gap: 80px`.

**Left heading:**
- `h2`: `clamp(30px, 4.5vw, 58px)`, copy: `Where the writing` / `*has [marked]gone.[/marked]*` — second line italic with `<Mark>` (yellow highlight) on "gone."

**Right:** Two-column publication table, `grid-template-columns: 1fr 1fr`, separated by `border-left: 1px solid rgba(26,20,16,.15)`. Each row: publication name in Newsreader `600`, `15.5px` + role label in Archivo `700`, `9px`, uppercase, `rgba(26,20,16,.55)`. Rows separated by `border-bottom: 1px solid rgba(26,20,16,.15)`, `padding: 12px 0`.

Publications: Forbes (Contributor), HuffPost (Contributor), Entrepreneur (Contributor), SEMrush Blog (Partner), Reader's Digest (Feature), The World Bank Blog (Contributor), SERPed (Contributor) | Harvard Business Review (Guest), The Next Web / TNW (Feature), Search Engine Journal (Contributor), Business.com (Contributor), Virgin Startup (Contributor), CNET (Feature).

CTA below: Ink button `See the full press archive →`.

---

### 6. Newsletter (§ 04) — Paper-2 Section

**Background:** `#e8e0cc`. `padding: 70px 56px`.

**Layout:** `grid-template-columns: 1fr 1fr`, `gap: 80px`, `align-items: center`.

**Left heading:** `Real case studies.` / `*[ink-bg]Zero filler.[/ink-bg]*` — ink background, yellow text on second line.

**Right — form:**
- Input: flex-1, `padding: 12px 16px`, `border: 1px solid #1a1410`, `background: #f1ebde`, Newsreader `400`, `15.5px`. Placeholder: `email@domain.com`
- Button: `background: #f5b81f`, `border: 1px solid #1a1410`, `border-left: none`, Archivo `800`, `10px`. Text: `Subscribe →`
- Sub-label: Archivo `700`, `9px`, `rgba(26,20,16,.35)`. Text: `SIA Newsletter · One–Two Emails a Month`
- Focus state on input: `outline: 2px solid #1a1410`, `outline-offset: -1px`

---

### 7. Footer
Reuse the existing `Colophon` component.

---

## Interactions & Behaviour

| Element | Behaviour |
|---------|-----------|
| Filter buttons | Client-side filter; re-renders the ledger. No page navigation. Active button fills ink. |
| Resource rows | Full row is clickable. Hover: bg → paper-2 (`#e8e0cc`), arrow → yellow (`#f5b81f`). |
| Filter button (inactive) hover | Border and text → full ink (`#1a1410`) |
| CTA buttons | `opacity: 0.85` on hover for ink buttons; lighten to `#ffc83a` for yellow buttons |
| Transitions | `0.12s ease` on all hover states — nothing slower |

---

## State Management

One piece of UI state: `filter` (string). Values: `'all' | 'tool' | 'calculator' | 'guide' | 'report'`. Default: `'all'`.

When filter changes, re-render only the ledger section. Category headers and counts update accordingly.

---

## Design Tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--color-paper` | `#f1ebde` | Primary background |
| `--color-paper-2` | `#e8e0cc` | Secondary bg, row hover |
| `--color-ink` | `#1a1410` | Text, borders, buttons |
| `--color-yellow` | `#f5b81f` | Accent, pills, CTAs |
| `--color-yellow-2` | `#ffc83a` | Yellow hover |
| `--color-ink-70` | `rgba(26,20,16,.70)` | Body text |
| `--color-ink-55` | `rgba(26,20,16,.55)` | Muted labels |
| `--color-ink-35` | `rgba(26,20,16,.32)` | Rules, dividers |
| `--color-ink-15` | `rgba(26,20,16,.15)` | Faint borders |
| `--font-serif` | Newsreader, Cormorant Garamond, Georgia | Headings, body, numbers |
| `--font-grot` | Archivo, Inter Tight, Helvetica Neue | Labels, UI, buttons |
| `--font-mono` | JetBrains Mono | Code/technical |

**Borders:**
- Strong: `1px solid #1a1410`
- Mid: `1px solid rgba(26,20,16,.32)`
- Faint: `1px solid rgba(26,20,16,.15)`
- Double rule: `1px` top + 3px gap + `3px` bottom (section starters)

**Border radius:** Zero everywhere.

**Section padding:** `0 56px` horizontal, `70px` top/bottom for major sections.

---

## Assets

No image assets are used in v1. The design is purely typographic.

Existing assets available in `public/assets/`:
- `SIA-Black-Favicon-260x260.png` — brand favicon
- `headshot.jpg` — portrait
- `SIA-LinkedIn-A-organic-blob.png` — blob-masked headshot

---

## Files in This Package

| File | Purpose |
|------|---------|
| `Resources Page v1.html` | Full-page design reference. Open in a browser to inspect the live design. |
| `Header.jsx` | SiteHeader component reference (already exists in the codebase) |
| `Footer.jsx` | Colophon component reference (already exists in the codebase) |
| `Primitives.jsx` | SCaps, Mark, Pill, HRule, DoubleRule primitives reference |

> **Note:** These HTML files use a proprietary DC runtime (`support.js`) and will not run standalone outside this design environment. Use them as visual references in a browser via the design tool, not as copy-paste source.
