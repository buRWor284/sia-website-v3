// SIA SiteHeader — dark sticky header with logo, The SIA Wire, nav, CTA

function SiteHeader({ activePage='Home' }) {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const CREAM = '#f1ebde', CREAM45 = 'rgba(241,235,222,.45)', CREAM50 = 'rgba(241,235,222,.50)',
        CREAM40 = 'rgba(241,235,222,.40)', CREAM12 = 'rgba(241,235,222,.12)';
  const NAV = ['Home','About','Speaking','EMOS','Fractional CMO','Resources','Contact'];
  const HREF = { Home:'#home', About:'#about', Speaking:'#speaking', EMOS:'#emos',
    'Fractional CMO':'#fractional-cmo', Resources:'#resources', Contact:'#contact' };
  const today = new Date();
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const dateline = `Est. 2004 · Global · ${days[today.getDay()]}, ${months[today.getMonth()]} ${today.getDate()}, ${today.getFullYear()}`;

  return React.createElement('header', {
    style: { background: INK, color: CREAM, position:'sticky', top:0, zIndex:100,
      fontFamily: GROT }
  },
    // Top row
    React.createElement('div', { style: { display:'grid', gridTemplateColumns:'auto 1fr auto',
      alignItems:'center', gap:20, padding:'14px 56px 12px', borderBottom:`1px solid ${CREAM12}` } },
      // Logo + wordmark
      React.createElement('div', { style: { display:'flex', alignItems:'center', gap:12 } },
        React.createElement(SiaLogoMark, { size: 30 }),
        React.createElement('div', null,
          React.createElement('div', { style: { fontFamily: SERIF, fontWeight:700, fontSize:17,
            color:CREAM, letterSpacing:'-0.01em', lineHeight:1 } }, 'Syed Irfan Ajmal'),
          React.createElement('div', { style: { fontFamily:GROT, fontWeight:700, fontSize:8.5,
            letterSpacing:'.22em', textTransform:'uppercase', color:CREAM45, marginTop:3 } },
            'SEO-PR \u00a0·\u00a0 GEO \u00a0·\u00a0 Content Marketing')
        )
      ),
      // The SIA Wire
      React.createElement('div', { style: { textAlign:'center' } },
        React.createElement('div', { style: { fontFamily:GROT, fontWeight:700, fontSize:9,
          letterSpacing:'.22em', textTransform:'uppercase', color:CREAM50 } }, 'The SIA Wire'),
        React.createElement('div', { style: { fontFamily:SERIF, fontStyle:'italic',
          fontSize:13, color:CREAM40, marginTop:3 } }, dateline)
      ),
      // Availability
      React.createElement('div', { style: { fontFamily:GROT, fontWeight:700, fontSize:9,
        letterSpacing:'.16em', textTransform:'uppercase', color:CREAM40, textAlign:'right' } },
        'Open for projects, Q3 2026')
    ),
    // Desktop nav
    React.createElement('div', { style: { display:'flex', justifyContent:'space-between',
      alignItems:'center', padding:'11px 56px' } },
      React.createElement('nav', { style: { display:'flex', alignItems:'center', gap:22, flexWrap:'wrap' } },
        NAV.map(label => React.createElement('a', {
          key: label,
          href: HREF[label] || '#',
          style: { fontFamily:GROT, fontSize:10, fontWeight:700, letterSpacing:'.16em',
            textTransform:'uppercase', color: label===activePage ? CREAM : CREAM50,
            textDecoration:'none', fontStyle: label==='EMOS' ? 'italic' : 'normal' }
        }, label))
      ),
      React.createElement('a', {
        href: CALENDLY, target:'_blank', rel:'noopener noreferrer',
        style: { fontFamily:GROT, fontWeight:800, fontSize:10, letterSpacing:'.12em',
          textTransform:'uppercase', background:YEL, color:INK,
          padding:'8px 15px', whiteSpace:'nowrap', textDecoration:'none' }
      }, 'Book a discovery call \u2192')
    )
  );
}

Object.assign(window, { SiteHeader });
