// SIA Bureau Primitives — IIFE-scoped, React accessed lazily (inside function bodies only)
(function() {
  // h() calls React.createElement at call time, not at script evaluation time
  function h() { return React.createElement.apply(React, arguments); }

  var PAPER="#f1ebde", INK="#1a1410", INK55="rgba(26,20,16,.55)", INK35="rgba(26,20,16,.32)",
      INK70="rgba(26,20,16,.70)", YEL="#f5b81f",
      SERIF="'Newsreader','Cormorant Garamond',Georgia,serif",
      GROT="'Archivo','Inter Tight','Helvetica Neue',sans-serif";

  function SCaps(p) {
    return h('span', {
      style: { fontFamily: GROT, fontWeight: p.weight||700, fontSize: p.size||11,
        letterSpacing: p.ls||'0.22em', textTransform: 'uppercase',
        color: p.color||INK55, ...(p.style||{}) }
    }, p.children);
  }

  function Mark(p) {
    return h('span', {
      style: { background: YEL, color: INK, padding: '0 0.12em',
        boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone' }
    }, p.children);
  }

  function Pill(p) {
    return h('span', {
      style: { display: 'inline-block', padding: '4px 9px 5px', background: YEL,
        color: INK, fontFamily: GROT, fontWeight: 800, fontSize: p.size||10.5,
        letterSpacing: p.ls||'0.16em', textTransform: 'uppercase' }
    }, p.children);
  }

  function HRule(p) {
    return h('div', { style: { height: p.thick ? 2 : 1, background: p.color||INK, ...(p.style||{}) } });
  }

  function DoubleRule(p) {
    var c = p.dark ? 'rgba(241,235,222,.6)' : INK;
    return h('div', { style: { borderTop: '1px solid '+c, ...(p.style||{}) } },
      h('div', { style: { marginTop: 3, borderTop: '3px solid '+c } })
    );
  }

  function SectionMast(p) {
    var c = p.dark ? 'rgba(241,235,222,.85)' : INK;
    return h('div', { style: { marginBottom: 32 } },
      h(DoubleRule, { dark: p.dark }),
      h('div', { style: { display:'flex', alignItems:'baseline', gap:14, padding:'10px 0 6px' } },
        h(Pill, { size:11, ls:'0.18em' }, '\u00a7 '+p.n),
        h(SCaps, { color:c, size:11.5, ls:'0.22em' }, p.label),
        h('div', { style: { flex:1, height:1, background: p.dark?'rgba(241,235,222,.4)':INK35 } }),
        h(SCaps, { color: p.dark?'rgba(241,235,222,.5)':INK55, size:10.5, ls:'0.18em' }, 'Vol. XV \u00b7 \u2116 '+p.n)
      ),
      h('div', { style: { marginTop:-1, borderTop:'1px solid '+(p.dark?'rgba(241,235,222,.6)':INK) } })
    );
  }

  function Flag(p) {
    var w=p.w||24, h2=Math.round(w*0.625);
    var wrap = { display:'inline-block', verticalAlign:'-2px', border:'1px solid '+INK, marginRight:8 };
    if (p.c==='SE') return h('svg',{viewBox:'0 0 16 10',width:w,height:h2,style:wrap},h('rect',{width:16,height:10,fill:'#006AA7'}),h('rect',{x:5,width:2,height:10,fill:'#FECC00'}),h('rect',{y:4,width:16,height:2,fill:'#FECC00'}));
    if (p.c==='DK') return h('svg',{viewBox:'0 0 16 10',width:w,height:h2,style:wrap},h('rect',{width:16,height:10,fill:'#C8102E'}),h('rect',{x:5,width:2,height:10,fill:'#fff'}),h('rect',{y:4,width:16,height:2,fill:'#fff'}));
    if (p.c==='US') return h('svg',{viewBox:'0 0 16 10',width:w,height:h2,style:wrap},h('rect',{width:16,height:10,fill:'#fff'}),h('rect',{width:7,height:5.5,fill:'#3C3B6E'}));
    if (p.c==='PK') return h('svg',{viewBox:'0 0 16 10',width:w,height:h2,style:wrap},h('rect',{width:16,height:10,fill:'#01411C'}),h('rect',{width:4,height:10,fill:'#fff'}));
    if (p.c==='EU') return h('svg',{viewBox:'0 0 16 10',width:w,height:h2,style:wrap},h('rect',{width:16,height:10,fill:'#003399'}));
    return null;
  }

  function SiaLogoMark(p) {
    var size=p.size||30;
    return h('div', { style: { width:size, height:size, background:YEL, display:'flex',
      alignItems:'center', justifyContent:'center', fontFamily:GROT, fontWeight:900,
      fontSize:Math.round(size*0.43), color:INK, flexShrink:0 } }, 'SIA');
  }

  Object.assign(window, { SCaps, Mark, Pill, HRule, DoubleRule, SectionMast, Flag, SiaLogoMark,
    PAPER, PAPER2:'#e8e0cc', INK, INK70, INK55, INK35, INK15:'rgba(26,20,16,.15)',
    YEL, YEL2:'#ffc83a', SERIF, GROT, MONO:"'JetBrains Mono',monospace",
    CALENDLY:'https://calendly.com/sia_dmr_agency/emos',
    EMOS_URL:'https://dmr.agency/earnedmediaOS/' });
})();
