# Handoff: Syed Irfan Ajmal — Speaker & Press Suite

## Overview
Three marketing documents for **Syed Irfan Ajmal** (SIA) — serial entrepreneur, fractional CMO, author, and international speaker — sharing one editorial "newspaper / wire-service" visual system:

1. **Speaker One-Sheet (Warm)** — a single A4 page a conference organiser can skim or print: hero pitch, signature talks, social proof, bylines wall, booking CTA.
2. **Speaker Media Kit** — a 5-page A4 document (Cover · Profile · Signature Talks · Proof · Booking) — the long-form version of the one-sheet.
3. **Press Kit** — a long-scroll web page (the "SIA Wire") for journalists: copy-ready bios & fast facts, expert-comment topics, "as featured in" wall, client results, testimonials, speaker reel, downloads, and a brand-assets panel.

All three are **print/PDF-aware**: the two speaker files are laid out on real A4 sheets (210mm × 297mm); the press kit is a responsive web page.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing the intended look, layout, and behavior. They are **not** production code to ship directly.

The task is to **recreate these designs in the target codebase's environment** (e.g. the existing syedirfanajmal.com stack — React/Next, Astro, plain templates, whatever is in use) following its established component patterns, routing, and asset pipeline. If no environment exists yet, pick the most appropriate framework and implement them there. The two speaker documents are print artifacts — implement them so they render correctly to PDF at A4 (consider a print stylesheet or a server-side HTML→PDF step).

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, and layout. Recreate pixel-faithfully using the codebase's libraries. Exact hex values, fonts, and measurements are listed below and are present in the HTML `:root` blocks and inline styles.

---

## Shared Design System ("The Bureau / SIA Wire")

### Fonts (Google Fonts)
```
Newsreader  — serif, optical-size 6..72, weights 400/500/600/700 + italics  → body, headlines, quotes
Archivo     — grotesque, weights 400–900                                     → labels, eyebrows, UI, all-caps
JetBrains Mono — weights 400/500/700                                         → mono accents / data
```
Loaded via one `<link>` to `fonts.googleapis.com/css2?family=Newsreader…&family=Archivo…&family=JetBrains+Mono…`.

CSS variables used everywhere:
```css
--serif: 'Newsreader', Georgia, serif;
--grot:  'Archivo', 'Helvetica Neue', Arial, sans-serif;
--mono:  'JetBrains Mono', ui-monospace, monospace;
```

### Colors
| Token | Press Kit | Speaker files | Use |
|-------|-----------|---------------|-----|
| `--paper`   | `#FAFAFA` | `#FBF8F1` (warmer cream) | page background |
| `--paper-2` | `#F0F0EE` | `#F1ECE0` | tinted panels |
| `--ink`     | `#1A1410` | `#1A1410` | text, rules, dark fills |
| `--yellow`  | `#F5B81F` | `#F5B81F` | primary accent (highlights, pills, CTAs) |
| `--yellow-2`| `#FFC83A` | `#FFC83A` | hover / lighter accent |
| `--blue`    | `#2F6FE0` | — | press-kit footer status accents |
| hero tint   | — | `#FCF4DA` | speaker hero band background |
> Ink is also used at opacity steps: `--ink-70 .70`, `--ink-55 .55`, `--ink-35 .32`, `--ink-15 .15`, `--ink-08 .08`, `--ink-05 .05`. Paper has matching light steps for dark surfaces (`--paper-72`, `--paper-55`, etc.).

Note the **two paper temperatures**: the press kit is on cool near-white `#FAFAFA`; the speaker documents are on warm cream `#FBF8F1` ("Warm" variant). Keep this distinction.

### Recurring motifs (reuse as shared components)
- **Ticker bar** — full-width black strip, centered all-caps Archivo at ~8.5px, yellow `////` separators. Top of speaker docs.
- **Masthead row** — small circular/square portrait + name (Newsreader 700) + role line (Archivo caps) on the left; a yellow "OPEN FOR BOOKINGS / doc label" pill on the right.
- **Double rule** — a 1px ink line with a 3px ink line 2.5px below it (`.double-rule` + `::after`). Section dividers.
- **Section masthead** (`.mast`) — yellow `§ NN` square + all-caps section label + flexible 1px rule + italic note. Numbered editorial section headers.
- **Stat ribbon / chips** — bordered cells, Newsreader number + Archivo caps label.
- **Logo wall** (`.logowall` / `.logo-grid`) — grayscale press logos in bordered cells; individual logos size-tuned via `.big`, `.huff`, inline `max-height`.
- **Newsprint dot texture** — `::before` radial-gradient dot pattern at ~4.5% opacity, `mix-blend-mode: multiply`, on the speaker sheets.
- **Yellow highlight** (`.mark`) — inline text highlight, `box-decoration-break: clone`.
- **Filed-from dateline** testimonials — quote with an "Filed from {City}" Archivo caps kicker and an avatar + name + role byline.

---

## File 1 — Speaker One-Sheet (Warm)
`SIA Speaker One-Sheet - Warm.html`

**Format:** one A4 sheet, `.sheet { width:210mm; height:297mm; }`, 13mm horizontal padding, on a `#cac4b8` desk backdrop. Designed to print to a single page.

**Sections, top → bottom:**
1. **Ticker** — credentials run (countries spoken in, audience size, since 2013, clients).
2. **Masthead** — 40px square portrait (`speaker-sheet-assets/headshot.jpg`), name "Syed Irfan Ajmal", role line; right side scaps + yellow "OPEN FOR BOOKINGS" pill.
3. **Double rule.**
4. **Hero** (`grid 0.72fr / 1fr`, on `#FCF4DA` band): left **marker** = big "22" (Newsreader 62px, yellow underline) + "YEARS…" label + yellow tag; right **heromain** = eyebrow, `h1` (Newsreader 700, 43px, with italic `.em` and yellow `.mark` spans), sub paragraph, and a row of bordered **chips** (one inverted `.req` chip in ink/yellow). A faint giant "Speaking" ghost word sits behind.
5. **Hero photo** — `speaker-sheet-assets/panel-atm.jpg`, ink caption chip "Panel · Arabian Travel Market, Dubai".
6. **Signature talks** — section masthead + talk list (titles Newsreader, takeaways).
7. **Testimonials** — three "Filed from {London/SF/Bali}" quotes with avatars: `ash-ali.jpg`, `chuck-wang.jpg`, `brie-moreau.jpg`.
8. **Bylines & citations wall** — `.logowall` of 13 grayscale logos from `speaker-sheet-assets/logos/` (forbes, hbr, business-insider, huffpost `.huff`, entrepreneur, msn, tnw, business-com, semrush, sew `.big`, serped, worldbank `.big`).
9. **Booking footer** — contact + CTA.

**Type scale highlights:** hero `h1` 43px/.93; marker number 62px/.84; section labels Archivo 8–9px caps, letter-spacing .08–.22em; body 11.5px Newsreader.

## File 2 — Speaker Media Kit
`SIA Speaker Media Kit.html`

**Format:** five stacked A4 pages, `.page { width:210mm; height:297mm; }`, 14mm padding, same `#cac4b8` backdrop and dot texture. Each page tagged `data-screen-label`.

1. **01 Cover** — ticker, masthead (42px portrait + yellow doc-label pill "SPEAKER MEDIA KIT"), hero (`grid 0.34fr/1fr`, marker "22" 66px, `h1` 50px), full-width photo **band** (`audience-dmss.jpg`, 178px) with ink caption + yellow statline "15+ international stages".
2. **02 Profile** — running head, bio, portrait (`headshot.jpg`) with caption + pull-quote.
3. **03 Signature Talks** — talk cards with abstracts/takeaways.
4. **04 Proof** — photo strip (`speaking-mic.jpg`, `panel-atm.jpg`, `on-stage.jpg`), four "Filed from" testimonials (`ash-ali`, `brie-moreau`, `chuck-wang`, `maryam`), and the full grayscale logo wall (huffpost `.big`, sew `.big`, worldbank `.big`).
5. **05 Booking** — formats, fees note, contact CTA.

Shared running head (`.rh`), page foot (`.pgfoot`), and section mastheads give it a magazine spine.

## File 3 — Press Kit ("SIA Wire")
`Press Kit - Syed Irfan Ajmal.html`

**Format:** responsive long-scroll web page (not A4). Cool paper `#FAFAFA`. Sticky top nav with SIA mark, nav links, and a yellow "MEDIA ENQUIRIES →" button. Content is organised into numbered editorial sections (`§ 01`–`§ 10`) via `.mast-row` (yellow `§ NN` pill + scaps label + flex rule + folio "Vol. XV · № NN").

**Sections:**
- **Hero** — masthead, then a 6-cell **stat strip** (22 yrs / 300+ clients / 4 regions / 1.5M visitors / 1,000+ media links / 4 countries) and a portrait (`assets/headshot.jpg`) with a giant ghost "22+" credential block.
- **§01 Fast Facts** — copy-ready factsheet with a **Copy** button (`copyBlock()` writes to clipboard).
- **§02 Bios** — short/medium/long bios, each with its own copy button.
- **§03 Expert Comment** — topics SIA speaks to.
- **§04 As Featured In** — `.logo-grid` of 10 logos from `assets/press-logos/` (forbes, hbr, huffpost `max-height:74px`, the-next-web, entrepreneur, msn.svg, world-bank `max-height:51px`, search-engine-watch `max-height:62px`, semrush, serped). **Note the size overrides** — HuffPost +20%, World Bank +30% vs. their default cell size — preserve these.
- **Forbes ME clipping** — two-page print scan (`assets/press/forbes-me-article-p1.jpg`, `-p2.jpg`), each opening full-size; caption + per-page links + "16 in-depth case studies: dmr.agency/case-studies" line.
- **§05 Client Results** — outcome cards.
- **§06 What People Say** — testimonial cards. **Avatars are hotlinked** from `https://www.syedirfanajmal.com/assets/testimonials/{brett-helling.jpeg, imani-lea-brown.jpg, ash-ali.jpg, brie-moreau.jpg, chuck-wang.jpg, maryam-arshad-mahmood.jpg}`. Photos are grayscale and animate to full color on card **hover** (`.tcard:hover cite .avatar { filter: grayscale(0); }`).
- **§07 Latest / §08 Watch** — **Speaker reel gallery** mirroring the live /speaking page: a 16:9 featured YouTube `<iframe id="reel-iframe">` plus a grid of six reel thumbnails (`<button class="reel">`). Clicking a reel calls `playReel(btn)` which swaps the iframe `src` (with `autoplay=1` + optional `start`), updates the caption, and moves the `.active` class. Thumbnails are hotlinked YouTube `hqdefault.jpg` images; video IDs are on `data-yt`/`data-start`. Playlist link below.
- **§09 Downloads** — links to ZIP / PDFs / Bios.txt (these target files are produced separately and may 404 until added).
- **§10 Get In Touch** — contact CTA.
- **Brand panel** — `assets/brand/sia-logo-primary.svg` (primary), `-reversed.svg` (on dark), `-mono.svg` (mono), `sia-favicon.svg`, plus color swatches and a type specimen.
- **Footer (colophon)** — large italic Newsreader wordmark "Syed Irfan Ajmal" (`clamp(48px,6vw,76px)`, weight 800, italic) + description with bold **DMR.agency**; three columns (**The Work / Navigate / Connect**, plain uppercase Archivo heads, Connect starts with Contact); a 1px ink rule; uppercase copyright line; then a bottom row: `mailto:` email (ink-70) + two **blue** status badges (`2 Fractional CMO spots · Q3 2026`, `EMOS founding class · Apply now`, each with a blue dot) on the left, **Privacy Policy / Terms / Refund Policy** on the right. This footer matches the live home-page footer.

**SEO/meta:** the page carries OG/Twitter tags, JSON-LD, and `<meta name="robots" content="noindex">` (pre-launch). Carry these over verbatim.

---

## Interactions & Behavior
- **Copy buttons** (press kit) — `copyBlock(btn)` copies the associated factsheet/bio text to the clipboard and shows a transient "Copied" state.
- **Speaker reel** (press kit) — `playReel(btn)` swaps the featured YouTube iframe, autoplays, updates caption, sets `.active`. Default featured clip starts at `start=743`.
- **Testimonial hover** (press kit) — avatar `filter: grayscale(1) → 0` over `.15s`.
- **Logo / reel hovers** — grayscale→color on hover; links get a 1px yellow underline on hover.
- **No SPA routing or data fetching** — these are static documents. Internal links use site-relative paths (`/about`, `/speaking`, `/emos`, …) that resolve once on the real site.

## Responsive behavior
- **Press kit** is fully responsive (stat strip, hero grid, logo grid, footer columns collapse on narrow viewports; reel grid 3→2→1 columns).
- **Speaker one-sheet / media kit** are fixed A4 artifacts centered on a desk backdrop; they are meant for print/PDF, not fluid web layout. Recreate at A4 and provide a print path.

## Design Tokens (quick reference)
```
Colors      see table above. Accents: yellow #F5B81F / #FFC83A; blue #2F6FE0 (press footer)
Papers      #FAFAFA (press, cool) · #FBF8F1 (speaker, warm) · #F1ECE0 panel · #FCF4DA hero tint
Ink         #1A1410 (+ opacity steps .70/.55/.32/.15/.08/.05)
Fonts       Newsreader (serif) · Archivo (grotesque) · JetBrains Mono
Caps labels Archivo 700–800, 7–9px, letter-spacing .08–.22em, uppercase
Rules       1px ink; "double rule" = 1px + 3px @ 2.5px gap
Borders     1px solid ink on cells/chips/photos; no border-radius (square editorial frames)
Highlight   .mark = yellow bg, box-decoration-break: clone
Page size   210mm × 297mm (A4) for the two speaker docs
```

## Assets
All bundled under this folder; relative paths are preserved so the HTML renders offline.

- `speaker-sheet-assets/` — used by **both speaker files**: `headshot.jpg`, on-stage / panel / audience / mic photos, six testimonial avatars, and `logos/` (13 press logos: forbes, hbr, business-insider.webp, huffpost, entrepreneur, msn.webp, tnw, business-com, semrush, sew.jpeg, serped.jpeg, worldbank).
- `assets/headshot.jpg` — press-kit hero portrait.
- `assets/press-logos/` — press-kit "as featured in" wall (forbes, hbr, huffpost, the-next-web, entrepreneur, msn.svg, world-bank, search-engine-watch, semrush, serped).
- `assets/press/` — `forbes-me-article-p1.jpg`, `forbes-me-article-p2.jpg` (clean two-page Forbes ME scan).
- `assets/brand/` — `sia-logo-primary.svg`, `sia-logo-reversed.svg`, `sia-logo-mono.svg`, `sia-favicon.svg`.

### External (hotlinked, NOT bundled)
The press kit references live assets that must remain reachable (or be localized) on the target site:
- Testimonial avatars: `https://www.syedirfanajmal.com/assets/testimonials/*.jpg`
- Speaker-reel thumbnails: `https://i.ytimg.com/vi/{id}/hqdefault.jpg`
- Reel video iframes: `https://www.youtube.com/embed/{id}` (IDs in `data-yt`)
- Google Fonts (all three files)

These will not render in an offline preview but resolve in a normal browser / on the live domain. Source headshots and event photos came from SIA's own photo library.

## Files in this bundle
```
Press Kit - Syed Irfan Ajmal.html      ← press kit (web, long-scroll)
SIA Speaker One-Sheet - Warm.html      ← one-sheet (A4, 1 page)
SIA Speaker Media Kit.html             ← media kit (A4, 5 pages)
speaker-sheet-assets/…                 ← assets for the two speaker files
assets/…                               ← assets for the press kit (headshot, press-logos, press, brand)
README.md                              ← this file
```
The brand color/type system is also documented in the SIA Design System project (`colors_and_type.css`, `README.md`) if the developer has access — but this README is self-sufficient.
