# Handoff: SIA Client Dashboard + CMO Pilot Proposal

## Overview
Two interconnected pages for Syed Irfan Ajmal's personal brand site (syedirfanajmal.com):

1. **Client Dashboard** — A private, per-client landing page. Serves as a workspace index linking to all deliverables prepared for a specific client (here: Sajid Shah / Resourcex.io).
2. **CMO Pilot Proposal** — A one-page engagement document styled as a newspaper editorial broadsheet. Contains the full scope, term, investment, and next-step details for the Fractional CMO pilot with Resourcex × happy.co.

---

## About the Design Files
The `.dc.html` files in this bundle are **design references created in HTML** — high-fidelity prototypes showing the intended look, layout, and content. They are not production code to copy directly. The task is to **recreate these designs in the target codebase** (the SIA Next.js site at `github.com/buRWor284/sia-website-v3`) using its existing React components, design tokens, and patterns.

---

## Fidelity
**High-fidelity.** Both screens use final colors, typography, spacing, copy, and interactions from the SIA Design System. Recreate pixel-accurately using the codebase's existing libraries.

---

## Design System

All values come from the **SIA Design System** ("The Bureau" / "The SIA Wire"). Tokens are in `colors_and_type.css`.

### Color Tokens
| Token | Value | Usage |
|---|---|---|
| `--color-paper` | `#FAFAFA` | Primary background |
| `--color-paper-2` | `#F0F0EE` | Secondary bg, sidebar panels |
| `--color-ink` | `#1a1410` | All text, borders, fills, nav bg |
| `--color-yellow` | `#f5b81f` | Accent: marks, pills, CTA buttons, stat underlines |
| `--color-yellow-2` | `#ffc83a` | Yellow hover state |
| `--color-ink-70` | `rgba(26,20,16,.70)` | Body text |
| `--color-ink-55` | `rgba(26,20,16,.55)` | Muted labels, overlines |
| `--color-ink-35` | `rgba(26,20,16,.32)` | Rules, dividers |
| `--color-ink-15` | `rgba(26,20,16,.15)` | Faint borders |

Dark sections use ink bg + paper text with these transparencies:
- Body: `rgba(250,250,250,.72)`
- Captions: `rgba(250,250,250,.45)`
- Borders: `rgba(250,250,250,.25)`

### Typography
| Role | Family | Weights |
|---|---|---|
| Serif (headings + body) | Newsreader | 400, 500, 600, 700 (+ italic) |
| Grotesque (UI labels, nav, buttons) | Archivo | 400–900 |
| Monospace (meta, code) | JetBrains Mono | 400, 500, 700 |

### Key Type Rules
- All headings: Newsreader 700, sentence case, tight tracking (`-0.02em` to `-0.04em`)
- All labels/overlines/nav: Archivo 700, ALL CAPS, `letter-spacing: 0.16–0.22em`
- Body copy: Newsreader 400/italic, `font-size: 15–17.5px`, `line-height: 1.55–1.65`, `text-align: justify`
- Section numbers: `§ 01` in yellow pill + ALL CAPS grot label
- Stats/numbers: Newsreader 700, large size, 2px solid yellow underline

### Borders & Spacing
- **Zero border-radius everywhere** — the brand forbids rounded corners
- **No box-shadow** — elevation via borders only
- Primary border: `1px solid var(--color-ink)`
- Rule: `1px solid rgba(26,20,16,.32)`
- Double rule (section starters): 1px top + 3px bottom, 3px gap
- Section padding: `40–56px` horizontal, `48–64px` vertical

---

## Screen 1: Client Dashboard

**File:** `Client Dashboard.dc.html`  
**Route suggestion:** `/workspace/[clientSlug]` or `/client/[slug]`  
**Purpose:** Private landing page linking a named client to their prepared deliverables.

### Layout (top to bottom)
All sections are full-width. Max content width: `880px`, centered, with `40px` horizontal padding on the outer wrapper.

---

### 1. Site Header
**Background:** `var(--color-ink)`  
Two-row layout, full width, no max-width constraint.

**Row 1 — Identity bar**
- Padding: `12px 40px`
- Border-bottom: `1px solid rgba(250,250,250,.10)`
- Left: SIA logo mark — `32×32px` yellow square (`background: #f5b81f`), "SIA" in Archivo Black 900, 13px, ink color. Followed by wordmark "Syed Irfan Ajmal" in Newsreader 700 18px paper, and subtitle "Est. 2004 · GEO · SEO-PR · Content Marketing" in Archivo 700 9px, `letter-spacing: 0.22em`, uppercase, `rgba(250,250,250,.45)`.

**Row 2 — Nav bar**
- Padding: `0 40px`
- Links: HOME · ABOUT · SPEAKING · EMOS · FRACTIONAL CMO · RESOURCES · PRESS KIT · CONTACT
  - Archivo 700, 10px, `letter-spacing: 0.16em`, uppercase, `rgba(250,250,250,.60)`
  - Padding: `16px 18px` (first item: `16px 18px 16px 0`)
  - Hover: `rgba(250,250,250,1.0)`, transition `0.12s ease`
- CTA button (right): "BOOK A DISCOVERY CALL →"
  - Background `var(--color-yellow)`, color `var(--color-ink)`
  - Archivo 700, 10px, `letter-spacing: 0.14em`, uppercase
  - Padding: `11px 20px`
  - Hover: `background: var(--color-yellow-2)`

---

### 2. Ticker / Marquee Strip
**Background:** `var(--color-ink)`  
**Border-bottom:** `1px solid rgba(250,250,250,.10)`  
**Padding:** `9px 0`  
**Overflow:** hidden

Continuous scrolling marquee (CSS `animation: translateX` loop, 28s linear infinite, pauses on hover).

Content (repeated twice for seamless loop):
```
Forbes · HBR · SEMrush · TNW · Entrepreneur · SERPed · Search Engine Journal · World Bank  >>>  Spoken in PK · MY · ID · AE  >>>  4 Podcast Seasons  >>>
```
- Text: Archivo 700, 9.5px, `letter-spacing: 0.18em`, uppercase, `rgba(250,250,250,.55)`
- Separators (`·`): `rgba(250,250,250,.20)`
- Section dividers (`>>>`): JetBrains Mono 9px, `rgba(250,250,250,.20)`
- Items have `padding: 0 20px`; dividers have `padding: 0 24px`

---

### 3. Hero Section
**Background:** `var(--color-ink)`  
**Padding:** `56px 40px 64px`  
**Max-width:** `880px`

**Workspace badge** (split pill, no border-radius):
- Left half: background `var(--color-yellow)`, "PRIVATE WORKSPACE" — Archivo 800, 9px, `letter-spacing: 0.18em`, uppercase, ink color, padding `5px 10px`
- Right half: border `1px solid rgba(250,250,250,.25)`, "Resourcex.io" — Archivo 700, 9px, `letter-spacing: 0.18em`, uppercase, `rgba(250,250,250,.60)`, padding `5px 12px`
- Margin-bottom: `24px`

**Headline:**
- "Sajid Shah: your SIA" (normal) + line break + "*client workspace*" (italic)
- Newsreader 700, `clamp(36px, 5vw, 60px)`, `line-height: 0.96`, `letter-spacing: -0.03em`, `color: var(--color-paper)`
- Margin-bottom: `18px`

**Subtitle:**
- "Working assets prepared by Syed Irfan Ajmal. Shared privately for your review."
- Newsreader 400, 17px, `line-height: 1.6`, `rgba(250,250,250,.60)`, `max-width: 520px`

---

### 4. Documents Section
**Background:** `var(--color-paper)`  
**Padding:** `48px 40px 56px`

**Section mast (above cards):**
- Left: yellow pill "YOUR DOCUMENTS" — Archivo 800, 9px, `letter-spacing: 0.14em`, uppercase, ink, padding `3px 8px`
- Center: flex-grow horizontal rule, `1px solid rgba(26,20,16,.32)`
- Right: "2 items" — JetBrains Mono 9px, `rgba(26,20,16,.55)`
- Margin-bottom: `28px`
- Below mast: `3px solid var(--color-ink)` top border rule, margin-bottom `24px`

**Card container:**
- `border: 1px solid var(--color-ink)`
- `max-width: 880px`
- No border-radius, no shadow
- Two cards stacked, separated by `border-bottom: 1px solid var(--color-ink)`

**Each card — grid layout:** `grid-template-columns: 1fr auto`, gap `24px`, padding `32px 36px`, align-items `start`

**Card 1 — EMOS Proposal:**
- Title: "EMOS Private Founder's Intensive — Proposal" — Newsreader 700, 24px, `line-height: 1.15`, `letter-spacing: -0.01em`, ink
- Body: "Your personalised 8-week earned-media program: full scope, timeline, deliverables, and investment summary. Designed to peak at your acquisition announcement." — Newsreader 400, 15px, `line-height: 1.6`, `var(--color-ink-70)`
- CTA button: "View the proposal →" — Archivo 700, 10px, `letter-spacing: 0.14em`, uppercase, ink bg, paper text, padding `12px 20px`; hover: `opacity: 0.85`
- Type tag (top-right): "INTERACTIVE DECK" — Archivo 700, 9px, `letter-spacing: 0.18em`, uppercase, `var(--color-ink-55)`, background `var(--color-paper-2)`, border `1px solid var(--color-ink-35)`, padding `5px 10px`

**Card 2 — CMO Pilot Offer:**
- Title: "Fractional CMO Pilot Offer" — same type treatment as Card 1
- Body: "The one-page engagement outline for the Resourcex × happy.co account: scope, rate, success-fee structure, and pilot terms." — same as Card 1 body
- CTA button: "Open the PDF →" — same as Card 1 button style; links to CMO Pilot Proposal page
- Type tag (top-right): "PDF · ONE-PAGER" — Archivo 700, 9px, `letter-spacing: 0.18em`, uppercase, paper color text, **ink background**, border `1px solid var(--color-ink)`, padding `5px 10px`

---

### 5. Footer
**Background:** `var(--color-paper-2)`  
**Border-top:** `1px solid var(--color-ink-15)`  
**Padding:** `20px 40px`  
**Layout:** `flex`, space-between, align-center

- Left: "All materials are confidential and prepared exclusively for Sajid Shah / Resourcex.io. Please do not forward or share externally." — Newsreader italic 400, 12.5px, `var(--color-ink-55)`, `line-height: 1.5`
- Right: Yellow dot (`8×8px`, `background: var(--color-yellow)`, `border: 1.5px solid var(--color-ink)`, `border-radius: 50%`) + "CONFIDENTIAL" label — Archivo 700, 9px, `letter-spacing: 0.16em`, uppercase, `var(--color-ink-55)`

---

## Screen 2: CMO Pilot Proposal

**File:** `CMO Pilot Proposal.dc.html`  
**Route suggestion:** `/workspace/[clientSlug]/cmo-pilot` or a standalone PDF-style route  
**Purpose:** One-page engagement document — the full scope, term, investment structure, and CTA for the Fractional CMO Pilot with Resourcex × happy.co.

### Layout
`max-width: 900px`, centered, `background: var(--color-paper)`. Sections separated by `1px solid var(--color-ink-15)` borders.

---

### 1. Masthead
**Border-bottom:** `1px solid var(--color-ink)`  
**Padding:** `14px 40px`  
**Layout:** flex, space-between, align-center, 3 zones

- **Left:** SIA logo mark (28×28px yellow square, "SIA" Archivo 900 11px) + "Syed Irfan Ajmal" Archivo 700 10px, `letter-spacing: 0.22em`, uppercase, muted
- **Center:** "THE SIA WIRE" — Archivo 900, 13px, `letter-spacing: 0.30em`, uppercase, ink. Below: "Pilot Proposal · Fractional CMO · Advisory" — Archivo 400, 10px, `letter-spacing: 0.16em`, uppercase, muted
- **Right:** "June 2026" — Archivo 700, 10px, `letter-spacing: 0.16em`, muted. Below: "Vol. I · № 01" — JetBrains Mono, 10px, muted

---

### 2. Hero 3-Column Grid
`grid-template-columns: 200px 1fr 180px`  
**Border-bottom:** `1px solid var(--color-ink)`

**Left panel** (`border-right: 1px solid var(--color-ink)`, padding `28px 22px`, flex column gap `20px`):
- "PREPARED FOR" overline → "Resourcex.io" Newsreader 700 18px → "The Happy.co Account" Archivo uppercase muted
- "TERM" overline → "3-month" Newsreader 700 20px → "extendable to 6" muted
- "10 hrs" with 2px yellow underline → "/ week commitment" muted
- "START" overline → "First Monday after sign-off" Newsreader italic 13px

**Center** (padding `32px`, border-right `1px solid var(--color-ink)`):
- "Est. 2013 · Global" overline
- H1: "Fractional CMO" + line break + italic "*Pilot*" — Newsreader 700, `clamp(36px, 5vw, 56px)`, `line-height: 0.96`, `letter-spacing: -0.03em`
- Two pills: "TECHNICAL DEPTH" (ink bg, paper text) → arrow → "BUSINESS IMPACT" (yellow bg, ink text)
- Body paragraph, justified
- Flow diagram: 3-cell grid (`1fr 1fr 1fr`) — "Resourcex / Engineering" (paper-2 bg) | "Irfan / Account Lead" (yellow bg) | "Happy.co / Product" (paper-2 bg). Each cell: Archivo 800 9px label + Archivo 8px muted sublabel. Separated by `1px solid var(--color-ink-15)`.

**Right panel** (padding `28px 20px`, flex column):
- "CONTENTS" overline
- 4 dispatch rows (border-bottom `1px solid var(--color-ink-15)`, padding `10px 0`):
  - Each row: `§ 0N` in Archivo 700 9px yellow + section title Archivo 700 9px ink uppercase + italic serif subtitle 11px muted

---

### 3. §01 The Engagement
**Section mast:** yellow pill "§ 01" + "THE ENGAGEMENT" label + flex rule + "Vol. I · № 01" mono. Below: `3px solid var(--color-ink)` rule.

**2-column grid** (`1fr 1fr`, gap 32px):
- Left: body paragraph, Newsreader 400 15.5px, justified, `var(--color-ink-70)`
- Right: 2×2 data grid (border `1px solid var(--color-ink-15)`, gap 1px, bg `var(--color-ink-15)` to create cell lines):
  - "TERM": Newsreader 700 22px "3-month" + "extendable to 6" muted
  - "COMMITMENT": Newsreader 700 22px "10 hrs" with yellow underline + "per week" muted
  - "START" (full-width): Newsreader italic 14px "First Monday after sign-off"

**Timeline strip** (`grid-template-columns: repeat(4, 1fr)`, border `1px solid var(--color-ink)`, gap 1px, bg `var(--color-ink-15)`):
- 4 cells: "DAY 0", "SAFETY VALVE · DAY 30", "DAY 90", "MONTH 6"
- Each: yellow Archivo 700 9px label + Newsreader 13px description

---

### 4. §02 What the Pilot Covers
**Section mast** (same pattern, "§ 02")

**2-column border box** (`border: 1px solid var(--color-ink)`):

**Left (Included):** ink header bar ("INCLUDED" — Archivo 800, paper text). Body: 4 items, each with 14×14px yellow filled square (`border: 1.5px solid var(--color-ink)`) + Newsreader 14px text, gap 14px.

**Right (Not Included):** paper-2 header bar ("NOT INCLUDED" — Archivo 800, ink text). Body: 5 items, each with 14×14px outlined square (ink border, no fill) containing italic "×" + Newsreader 14px `var(--color-ink-55)`. Italic footnote below in 12.5px separated by `1px solid var(--color-ink-15)`.

---

### 5. §03 Investment
**Section mast** (same pattern, "§ 03")

**2-column grid** (`1fr 1fr`, gap 24px), each card `border: 1px solid var(--color-ink)`, padding `24px`:
- "BASE RETAINER": Newsreader 700 40px "USD 3,500" with 2px yellow underline + "/month" Archivo muted + italic footnote
- "SUCCESS FEE": Newsreader 700 40px "10%" with 2px yellow underline + "of new revenue" Archivo muted + italic explanation

**Context callout:** `background: var(--color-paper-2)`, `border-left: 3px solid var(--color-yellow)`, padding `16px 20px`, Newsreader 13.5px body.

**2-column info grid** (`1fr 1fr`, gap 16px, border `1px solid var(--color-ink-15)`):
- "SIMPLE EXIT": 14 days written notice copy
- "CASE STUDY": case study publication terms

---

### 6. §04 Dark CTA + Selected Results
**Background:** `var(--color-ink)`, padding `36px 40px`

**Section mast** (dark variant — paper-25 rule, paper-45 text)

**2-column grid** (`1fr 1fr`, gap 40px):

**Left (CTA):**
- Body: Newsreader 20px, `rgba(250,250,250,.72)`, margin-bottom 20px
- Byline: "Syed Irfan Ajmal" — Newsreader 700 17px, paper
- Button: "BOOK YOUR STRATEGY CALL →" — yellow bg, ink text, Archivo 700 10px, `letter-spacing: 0.16em`, padding `13px 22px`

**Right (Results):**
- Overline "SELECTED RESULTS" — Archivo 700, paper-45
- Results table: `border: 1px solid var(--color-paper-25)`, 3 rows:
  - "RIDESTER" (yellow) | "0 → 1.5M monthly visitors"
  - "CENTRIQ" (yellow) | "6× daily signups"
  - "NAT. TYRES" (yellow) | "$160K → $1.2M monthly revenue"
  - Row: Archivo 800 10px yellow label | Newsreader 14px paper-70 body
  - Row padding: `12px 16px`, border-bottom `1px solid var(--color-paper-25)`
- Italic footnote: "More at syedirfanajmal.com/fractional-cmo" — Newsreader italic, paper-45

---

### 7. Footer
`border-top: 1px solid var(--color-ink)`, padding `14px 40px`, flex space-between.

- "© 2013 – 2026 Syed Irfan Ajmal" — Archivo 9px, `letter-spacing: 0.12em`, uppercase, muted
- "SIA Enterprises Inc (WY C-Corp) · SIA Enterprises (PK Sole Prop.)" — same
- "sia@syedirfanajmal.com · www.syedirfanajmal.com" — same

---

## Interactions & Behavior

| Element | Behavior |
|---|---|
| Nav links | Hover → `color: rgba(250,250,250,1.0)`, `transition: 0.12s ease` |
| "Book a Discovery Call" button | Hover → `background: var(--color-yellow-2)` |
| Document card CTA buttons | Hover → `opacity: 0.85`, `transition: 0.12s ease` |
| Ticker / marquee | Scrolls continuously left at 28s per loop; pauses on hover |
| "BOOK YOUR STRATEGY CALL" | Links to Calendly / discovery call booking page |
| "Open the PDF →" | Links to CMO Pilot Proposal page (internal route) |
| "View the proposal →" | Links to EMOS Proposal (separate deliverable, not in this package) |

No entrance animations, scroll reveals, or parallax. Transitions: hover state changes only, 0.12–0.18s.

---

## Assets Used
| Asset | Source | Usage |
|---|---|---|
| SIA logo mark | CSS-drawn (yellow square + Archivo 900 text) | Site header |
| Paper grain texture | CSS (`radial-gradient` dot pattern, 5% opacity, `mix-blend-mode: multiply`) | Body background |
| Yellow availability dot | CSS circle (8×8px) | Footer confidentiality badge |

No external images are used in either design. No icon libraries — arrows are plain Unicode `→` characters.

---

## Files in This Package
| File | Description |
|---|---|
| `Client Dashboard.dc.html` | Client workspace index page (design reference) |
| `CMO Pilot Proposal.dc.html` | Fractional CMO one-pager engagement document (design reference) |
| `screenshot-client-dashboard.png` | Screenshot of the Client Dashboard |
| `screenshot-cmo-pilot-proposal.png` | Screenshot of the CMO Pilot Proposal (above the fold) |
| `README.md` | This file — full implementation spec |

The `.dc.html` files use a custom streaming runtime. Open them in a browser via a local file server to preview. Do not ship these files directly — recreate the designs in the Next.js codebase using its existing React components and patterns.

---

## Notes for the Developer
- The SIA design system source is at `github.com/buRWor284/sia-website-v3`. Check `src/lib/tokens.ts` for the canonical token values and `src/app/globals.css` for the `@theme` block.
- The ticker/marquee should be implemented with `overflow: hidden` + CSS `@keyframes` translateX, duplicating content for seamless looping.
- The "double rule" section separator pattern (1px top + 3px bottom, 3px gap) is a core brand element — apply it at the start of every major section.
- Rounded corners are forbidden brand-wide. `border-radius: 0` everywhere.
- No box-shadow anywhere. Grouping and elevation conveyed via borders only.
